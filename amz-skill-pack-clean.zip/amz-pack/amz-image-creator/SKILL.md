---
name: amz-image-creator
description: Sorftime 数据驱动的亚马逊电商图片创作。用 VOC/评论/关键词/用户场景/Q&A 等数据洞察指导图片内容和卖点呈现，生成主图/A+图片/社媒图，融合 GPT-Image-2 25 套场景模板与 Sorftime 市场数据，提高点击率和转化率。当用户要做图、设计主图、做A+图片、社媒图、产品图片、电商图片、listing图片、白底图、场景图，或说"做图/主图设计/A+图片/社媒图/产品图片/图片设计/电商图片/listing图片/白底图/场景图/image generation/e-commerce image/product photography/hero image/A+ content image/social media image/lifestyle image/infographic/flat lay/亚马逊主图/amazon product image/图片提示词/image prompt/data-driven image/VOC图片"时使用。默认 Amazon US，支持多站点。
---

# amz-image-creator — 数据驱动的电商图片创作

用 Sorftime 数据辅助生图：通过 VOC/评论/关键词/用户场景等数据洞察，指导图片内容和卖点呈现，提高点击率和转化率。

**图片渲染走三条兜底路径（按顺序尝试，任一条可用即可）**：

1. **Agent 自带生图能力**：Codex 的 `imagegen` 技能、Claude 的生图工具等——直接调用，最省事。
2. **本技能的便携封装**：`scripts/gen-image.sh --prompt "..." --out xxx.png [--size 1024x1024]`。它会自动转交给你配置的生图通道（环境变量 `AMZ_IMAGE_CMD`，或工作台脚本 `~/.codex/scripts/gen-image.sh`）。
3. **都没有**：仍然交付**完整英文提示词 + 尺寸/风格方案**（`gen-image.sh` 会把提示词存成 `*.prompt.txt`），由用户复制到任意生图工具出图。

> 也就是说：**没有配置生图通道时，第 ⑦ 环依然可用**（产出方案而非成品图），不会因为缺渲染环境卡住整条链路。

> 链路位置：第 7 环「做图」。上游 ← amz-listing-creator（卖点/关键词）+ amz-voc-analysis（场景/痛点）；下游 → 上架发布 → amz-ad-planning。全链路地图见 `shared/amz-workflow-map.md`。

## 前置检查

执行任何数据操作前，先运行通道检测：

```bash
python3 scripts/channel_check.py
```
> 🚨 **凭证缺失 / 额度用尽时的标准动作（必须执行）**
> - **未装配**：通道检测返回 `setup_required: true`（MCP 与 CLI 都不可用）时，不要凭空执行数据调用；明确告知用户「当前 agent 还没有装配 Sorftime 通道」，然后**原样输出** `channel_check.py` 返回的 `signup_url`。
> - **额度用尽**：通道可用但调用返回额度不足（`Code=694` / `Code=401` / `quota` / 余额不足 / Insufficient）时，**立刻停止后续调用**，告知用户额度已用尽，并原样输出同一个 `signup_url`。
> - 若 `signup_url` 为空或 `promo_enabled: false`：只说明「需要先开通 / 充值」，**不要输出任何链接**。
> - 有链接时必须给出**完整可点击**的链接，不要只说「请去官网开通」。
> 📘 通道能力边界 / domain 对照 / 错误码 / 已知限制见 [shared/CHANNEL.md](shared/CHANNEL.md)；MCP 工具 ↔ CLI 端点对照见 [shared/mcp-map.md](shared/mcp-map.md)；MCP 怎么配置见 [shared/mcp-setup.md](shared/mcp-setup.md)。
> 📐 **所有派生指标必须走口径守门层**：金额是最小单位（÷100）、`-1` 是缺失不是 0、趋势末月不完整——规则见 [shared/DATA-CONTRACT.md](shared/DATA-CONTRACT.md)，代码用 `scripts/amzdata.py` 与 `scripts/trend.py`，自检 `python3 scripts/data_check.py`。


根据输出选择 MCP 或 CLI 通道。默认站点：US（domain=1）。

## 核心流程（三阶段）

```
阶段一：Sorftime 数据辅助分析
  ↓
阶段二：生成图片提示语（Prompt Engineering）
  ↓
阶段三：调用 image_gen 渲染实际 PNG
```

### 阶段一：数据辅助分析

用 Sorftime 数据回答"图片应该展示什么"：

| 数据维度 | 数据来源 | 指导图片内容 |
|----------|----------|-------------|
| 用户场景/使用场景 | product_customers_say / product_reviews | 场景图展示真实使用环境 |
| 用户画像 | product_customers_say / reviews 分析 | 模特图选择匹配人群 |
| 卖得好的产品特征 | keyword_search_results / product_search / product_detail | 主图构图/角度参考竞品 |
| Q&A 常见问题 | product_reviews（问题类评论） | 信息图解答常见疑问 |
| VOC 核心卖点 | product_customers_say | 突出用户最关心的卖点 |
| 关键词趋势 | keyword_detail / keyword_trend | 图片文字包含高频搜索词 |
| Reddit 特征 | reddit_post_search | 社媒图风格参考 |

### 阶段二：提示语生成

基于数据分析结果，从 25 套场景模板中匹配最适合的模板，生成结构化英文提示语。详见 `references/image-templates.md` 和 `references/prompt-engineering-guide.md`。

### 阶段三：图片渲染

按 `shared/report-format.md` 的交付规范与下面的生图路径渲染：

```bash
# 路径 2：本技能的便携封装（内部会自动找可用的生图通道）
scripts/gen-image.sh --prompt "阶段二生成的英文提示语" \
                     --size 1024x1024 \
                     --out outputs/imagegen/<产品名>-<图位>.png
```

退出码说明：`0` = 已出图；`2` = 未配置生图通道（提示词已存盘，交付方案）。
已有产品实拍图、需要做一致性场景化改造时，把原图作为参考图交给 agent 自带的生图能力（`imagegen` / `image_gen`），或在你自己的 `AMZ_IMAGE_CMD` 里实现。

输出：实际 PNG 图片 + 数据辅助分析报告 + 提示语文档。

## MCP 通道

| 工具 | 用途 |
|------|------|
| `product_detail` | 获取产品 listing 详情（标题/卖点/价格/评分） |
| `product_reviews` | 获取用户评论（差评痛点/好评亮点） |
| `product_customers_say` | 获取 Amazon 总结的客户声音（VOC） |
| `keyword_detail` | 关键词详情（搜索量/CPC，用于图片文字选择） |

⚠️ raw 工具通过 `sorftime_raw_call` 调用。

## CLI 通道

```bash
# 产品详情
scripts/cli_call.sh ProductRequest '{"asin": "B0CVM8TXHP"}'

# 客户声音
scripts/cli_call.sh ProductCustomersSay '{"asin": "B0CVM8TXHP"}'

# 产品评论
scripts/cli_call.sh ProductReviewsQuery '{"asin": "B0CVM8TXHP", "pageIndex": 1}'

# 关键词详情
scripts/cli_call.sh KeywordRequest '{"keyword": "power bank"}'
```

## 输出格式

```markdown
# 📸 图片创作结果

## 数据辅助分析
- 核心卖点：[从 VOC/评论提取]
- 用户场景：[从客户声音提取]
- 高频关键词：[从关键词数据提取]
- 竞品图片参考：[从 product_search_results 提取]

## 生成图片清单
| 序号 | 图位 | 场景类型 | Prompt 摘要 | 文件 |
|------|------|----------|-------------|------|
| 1 | 主图 | Hero Image | ... | xxx-01.png |
| 2 | 场景图 | Lifestyle | ... | xxx-02.png |
| ... | ... | ... | ... | ... |
```

## 详细方法论

- `references/image-data-assistance.md`：数据辅助生图方法论（VOC/关键词/用户场景如何指导图片内容）
- `references/image-templates.md`：25 套场景模板摘要
- `references/prompt-engineering-guide.md`：图片提示语工程指南
