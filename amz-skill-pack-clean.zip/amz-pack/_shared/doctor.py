#!/usr/bin/env python3
"""全链路自检（doctor）—— 检查这套技能包在**当前 agent / 当前机器**上能不能跑。

用法：
    python3 scripts/doctor.py            # 人类可读自检报告
    python3 scripts/doctor.py --json     # 机器可读

检查项：
    1. 通道（MCP / CLI）是否可用
    2. CLI 凭证是否有效、剩余额度
    3. 共享文件是否齐全
    4. 一次真实 API 调用是否成功（0 消耗的 CoinQuery）
"""

import json
import shutil
import subprocess
import sys
from pathlib import Path

HERE = Path(__file__).resolve().parent          # <技能目录>/scripts 或 _shared
if HERE.name == "scripts":
    SHARED = HERE.parent / "shared"
    SKILL_ROOT = HERE.parent.parent
else:                                            # 直接跑 _shared 里的版本
    SHARED = HERE
    SKILL_ROOT = HERE.parent

REQUIRED_SHARED = ["CHANNEL.md", "mcp-map.md", "mcp-setup.md", "report-format.md",
                   "DATA-CONTRACT.md"]
EXPECTED_SKILLS = [
    "amz-selection", "amz-market-analysis", "amz-supply-chain", "amz-profit-calc",
    "amz-cpc-keywords", "amz-listing-creator", "amz-image-creator",
    "amz-ad-planning", "amz-voc-analysis", "amz-competitor-monitor",
]


def run(cmd, timeout=30):
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
        return r.returncode, r.stdout + r.stderr
    except (OSError, subprocess.SubprocessError) as e:
        return None, str(e)


def _signup_value(key, default):
    """signup 配置项：优先环境变量 > scripts/signup.env > shared/signup.env > 内置默认。"""
    import os
    env = os.environ.get(key, "").strip()
    if env:
        return env
    for cand in (HERE / "signup.env", SHARED / "signup.env"):
        if cand.is_file():
            try:
                for line in cand.read_text(encoding="utf-8").splitlines():
                    line = line.strip()
                    if line.startswith(key + "="):
                        return line.split("=", 1)[1].strip().strip('"').strip("'")
            except OSError:
                pass
    return default


def signup_url():
    """开通/充值链接。"""
    return _signup_value("SORFTIME_SIGNUP_URL", "https://open.sorftime.com/home?tag=NjE4OA~~")


def promo_code():
    """优惠码。"""
    return _signup_value("SORFTIME_PROMO_CODE", "6188")


def promo_suffix():
    """「，优惠码：6188」；未配置优惠码时返回空串。"""
    promo = promo_code()
    return f"，优惠码：{promo}" if promo else ""


def main():
    as_json = "--json" in sys.argv
    checks = []

    # 1. 通道（channel_check.py 与 doctor.py 同在 scripts/ 下）
    cc = HERE / "channel_check.py"
    if not cc.exists():
        cc = SHARED / "channel_check.py"
    rc, out = run([sys.executable, str(cc)]) if cc.exists() else (None, "channel_check.py 缺失")
    channel = {}
    if rc is not None:
        try:
            channel = json.loads(out)
        except json.JSONDecodeError:
            channel = {}
    checks.append({
        "name": "通道检测",
        "ok": bool(channel.get("recommended_channel")),
        "detail": channel.get("message", out.strip()[:80]),
    })
    checks.append({
        "name": "MCP 通道",
        "ok": bool(channel.get("mcp_available")),
        "detail": ", ".join(channel.get("evidence", {}).get("mcp", [])) or "未检测到 MCP 配置",
    })
    checks.append({
        "name": "CLI 通道",
        "ok": bool(channel.get("cli_available")),
        "detail": ", ".join(channel.get("evidence", {}).get("cli", [])) or "未检测到 sorftime 命令/凭证",
    })

    # 2. 共享文件
    missing = [f for f in REQUIRED_SHARED if not (SHARED / f).exists()]
    checks.append({
        "name": "共享文件",
        "ok": not missing,
        "detail": f"缺失 {missing}" if missing else f"{len(REQUIRED_SHARED)} 个齐全 ({SHARED})",
    })

    # 3. 技能是否齐全（在父目录里找同级 amz-*）
    siblings = {p.name for p in SKILL_ROOT.iterdir() if p.is_dir()} if SKILL_ROOT.is_dir() else set()
    absent = [s for s in EXPECTED_SKILLS if s not in siblings]
    is_shared_run = SKILL_ROOT.name.endswith("amz-pack-v2") or True
    checks.append({
        "name": "技能完整性",
        "ok": not absent,
        "detail": f"缺少 {absent}" if absent else f"10 个技能齐全",
        "note": "" if not absent else "（单技能安装时可忽略此项）",
    })

    # 3.5 口径守门层（纯本地检查，不消耗额度）
    ad = HERE / "amzdata.py"
    try:
        sys.path.insert(0, str(HERE))
        import amzdata  # noqa: PLC0415
        ok = (amzdata.money(12609) == 126.09 and amzdata.money(-1) is None
              and amzdata.is_partial_month(999999) is False)
        detail = "金额换算 / 缺失值 / 不完整月识别 均正常" if ok else "换算规则不符合预期"
    except Exception as e:  # noqa: BLE001
        ok, detail = False, f"{type(e).__name__}: {e}"
    checks.append({
        "name": "口径守门层 (amzdata.py)",
        "ok": ok,
        "detail": detail if ad.exists() else "amzdata.py 缺失",
    })

    # 4. 一次真实调用（CoinQuery 0 消耗）
    if shutil.which("sorftime"):
        rc, out = run(["sorftime", "api", "CoinQuery"], timeout=45)
        ok = '"Code": 0' in out or '"Code":0' in out
        left = ""
        for line in out.splitlines():
            if "RequestLeft" in line:
                left = line.strip().rstrip(",")
        checks.append({
            "name": "真实调用 (CoinQuery, 0 消耗)",
            "ok": ok,
            "detail": left or out.strip().splitlines()[-1][:80],
        })
        # 额度是否可用
        quota_ok = ok and not ('"RequestLeft": 0' in out or '"Coin": 0' in out)
        checks.append({
            "name": "额度可用",
            "ok": quota_ok,
            "detail": ("额度正常" if quota_ok else
                       f"额度已用尽，请充值{promo_suffix()}：{signup_url()}"),
        })
    else:
        checks.append({
            "name": "真实调用",
            "ok": False,
            "detail": "未安装 sorftime 命令，跳过（仅 MCP 模式可忽略）",
        })

    passed = sum(1 for c in checks if c["ok"])
    result = {"passed": passed, "total": len(checks), "checks": checks}

    if as_json:
        print(json.dumps(result, ensure_ascii=False, indent=2))
    else:
        print("Sorftime amz-* 技能包 · 环境自检")
        print("=" * 52)
        for c in checks:
            mark = "✅" if c["ok"] else "⚠️ "
            print(f"{mark} {c['name']}: {c['detail']}")
        print("=" * 52)
        print(f"通过 {passed}/{len(checks)}")
        if passed < len(checks):
            print("\n提示：只有 MCP 通道时，未安装 sorftime CLI 属正常情况。")
            print(f"如需开通 / 充值（含 7 天试用{promo_suffix()}）：{signup_url()}")

    sys.exit(0 if passed == len(checks) else 0)


if __name__ == "__main__":
    main()
