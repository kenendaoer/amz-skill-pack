# MCP 工具 ↔ CLI 端点 对照表

> 用途：技能里写「用 X 数据」时，MCP 通道用左边的工具，CLI 通道用右边的端点。
> 实测时间：2026-09-16，Sorftime MCP 在线 **105 个工具**（服务端 v1.1.6）。

---

## 一、产品类

| MCP 工具 | CLI 端点 | 说明 |
| --- | --- | --- |
| `product_detail` | `ProductRequest` | 单品详情（CLI 支持 ≤10 个 ASIN 批量） |
| `product_search` | `ProductSearch` | 多维商品搜索 |
| `product_search_from_name` | `ProductSearchFromName` | 按名称搜品 |
| `product_search_from_history` | `ProductSearch`（带 `queryMonth`） | 历史回溯 |
| `product_trend` | `ProductRequest`（`trend=1` + 日期范围） | ⚠️ 亚马逊无 `ProductTrend` 端点 |
| `product_variations` | `ProductVariations` | 变体矩阵 |
| `product_reviews` | `ProductReviewsQuery` / `ProductReviewsCollection` | 评论查询 / 实时采集 |
| `product_traffic_terms` | `ASINRequestKeyword` | 反查流量词 |
| `product_customers_say` | `ProductCustomersSay` | 评论 AI 摘要 |
| `product_report` | `ProductAssistant` | AI 单品分析报告（异步） |
| `similar_product_feature` | `SimilarProductFeature` | 同类目特征聚合 |
| `competitor_product_keywords` | —（CLI 无对应） | 竞品关键词对比 |
| `product_ranking_trend_by_keyword` | `ASINKeywordRanking` | 关键词下排名趋势 |
| `potential_product` ⭐ | —（CLI 用本地隐赚代理分） | 隐赚指数 HPI |

## 二、关键词 / 类目类

| MCP 工具 | CLI 端点 |
| --- | --- |
| `keyword_detail` | `KeywordRequest` |
| `keyword_list` / `keyword_list_from_history` | `KeywordQuery` |
| `keyword_trend` | `KeywordRequest`（趋势部分） |
| `keyword_extends` | `KeywordExtends` |
| `keyword_search_results` | `KeywordSearchResults` |
| `category_tree` | `CategoryTree` |
| `category_name_search` | `CategorySearchFromName` |
| `category_report` | `CategoryRequest` |
| `category_report_from_history` | `CategoryRequest`（带 `queryDate`） |
| `category_trend` | `CategoryTrend` |
| `category_keywords` | `CategoryRequestKeyword` |
| `search_categories_broadly` | `CategoryProducts`（近似） |
| `category_search_from_top_node` | `CategoryTree` + 本地筛选 |

## 三、多平台

| 平台 | MCP 工具前缀 | CLI 端点前缀 | domain |
| --- | --- | --- | --- |
| Walmart | `walmart_*`（18 个） | `walmart_*` | 21 |
| Shopee | `shopee_*`（16 个） | `shopee_*` | 201+ |
| TikTok | `tiktok_*`（18 个） | `tiktok_*` | 见官方文档 |
| Temu | `temu_*`（9 个） | `temu_*` | 见官方文档 |
| 1688 | `ali1688_*`（6 个） | `ProductSearch` 等（复用产品端点） | **601** |
| Reddit（社媒） | `reddit_*`（3 个） | —（CLI 无对应） | — |

## 四、通用

| MCP 工具 | 用途 | 消耗 |
| --- | --- | --- |
| `get_time` | 服务器时间 / 连通性自检 | 0 |
| `sorftime_raw_call` | 透传调用任意未注册工具 | 视工具而定 |
| `get_favorite_keyword` / `favorite_keyword` / `change_favorite_keyword` / `del_favorite_keyword` | 关键词收藏夹管理 | 视工具而定 |

## 五、CLI 独有（MCP 无对应）

监控注册（`KeywordBatchSubscription`、`ProductSellerSubscription`、`BestSellerListSubscription`）、
AI 报告（`CategoryAssistant`、`ProductAssistant`）、实时采集（`ProductRealtimeRequest`）、
官方变体销量（`AsinSalesVolume`）、Alexa 问答（`AlexaQuestions*`）、
历史回溯（`KeywordProductRanking`、`ASINKeywordRanking`）、
账号额度（`CoinQuery`、`CoinStream`、`RequestStreamMonth`）。
