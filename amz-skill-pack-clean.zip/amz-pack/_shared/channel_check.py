#!/usr/bin/env python3
"""Sorftime 双通道检测（MCP / CLI）—— 跨 agent 通用版。

设计目标：同一套技能装到任何 agent（Codex / Claude Code / Claude Desktop / OpenClaw / 其它）
都能正确判断「有没有 MCP、有没有 CLI」，而不是只认某一种配置方式。

用法：
    python3 scripts/channel_check.py            # 输出 JSON
    python3 scripts/channel_check.py --quiet    # 只输出 recommended_channel

退出码：
    0 = 至少一个通道可用
    1 = 两个通道都不可用（会打印注册引导）
"""

import json
import os
import shutil
import subprocess
import sys
from pathlib import Path

DEFAULT_SIGNUP_URL = "https://open.sorftime.com/home?tag=NjE4OA~~"
DEFAULT_PROMO_CODE = "6188"
MARKERS = ("sorftime", "mcp.sorftime.com")
HERE = Path(__file__).resolve().parent


_OFF = {"", "off", "none", "no", "-", "false", "0"}


def _env_value(key: str, default: str) -> str:
    """取 signup 配置项。

    优先级：环境变量 > 本机个人配置(~/.sorftime/signup.env) > 随包配置(scripts/signup.env) > 内置默认。
    返回空字符串表示「关闭这一项」——链接为空则不输出任何链接，优惠码为空则不显示优惠码。
    （把包发出去时，接收方读的是包内 signup.env；自己用时可在家目录配置里关掉。）
    """
    def _parse(text):
        for line in text.splitlines():
            line = line.strip()
            if line.startswith(key + "="):
                return line.split("=", 1)[1].strip().strip('"').strip("'")
        return None

    env = os.environ.get(key)
    if env is not None:
        env = env.strip()
        return "" if env.lower() in _OFF else env

    personal = [
        Path.home() / ".sorftime" / "signup.env",
        Path.home() / ".config" / "sorftime" / "signup.env",
    ]
    for f in personal + [HERE / "signup.env"]:
        if f.is_file():
            try:
                val = _parse(f.read_text(encoding="utf-8"))
            except OSError:
                continue
            if val is not None:
                return "" if val.lower() in _OFF else val
    return default


def signup_url() -> str:
    """开通 / 充值链接。"""
    return _env_value("SORFTIME_SIGNUP_URL", DEFAULT_SIGNUP_URL)


def promo_code() -> str:
    """优惠码（与链接一起展示）。"""
    return _env_value("SORFTIME_PROMO_CODE", DEFAULT_PROMO_CODE)


def check_quota():
    """用 CoinQuery 查额度（0 消耗）。返回 dict；无法检查时 checked=False。"""
    if not shutil.which("sorftime"):
        return {"checked": False, "reason": "未安装 sorftime CLI"}
    try:
        r = subprocess.run(["sorftime", "api", "CoinQuery"],
                           capture_output=True, text=True, timeout=45)
    except (OSError, subprocess.SubprocessError) as e:
        return {"checked": False, "reason": f"调用失败: {e}"}

    out = r.stdout + r.stderr
    if '"Code": 0' not in out and '"Code":0' not in out:
        return {"checked": False, "reason": out.strip().splitlines()[-1][:80] if out.strip() else "无输出"}

    def grab(key):
        for line in out.splitlines():
            if key in line:
                digits = "".join(ch for ch in line.split(":")[-1] if ch.isdigit() or ch == "-")
                return int(digits) if digits not in ("", "-") else None
        return None

    left, coins = grab("RequestLeft"), grab("Coin")
    ok = (left is None or left > 0) and (coins is None or coins > 0)
    return {"checked": True, "requests_left": left, "coins": coins, "ok": ok}


# ---------------------------------------------------------------- MCP 检测

def _readable(path: Path) -> bool:
    try:
        return path.is_file() and os.access(path, os.R_OK)
    except OSError:
        return False


def _file_mentions_sorftime(path: Path) -> bool:
    if not _readable(path):
        return False
    try:
        text = path.read_text(encoding="utf-8", errors="ignore").lower()
    except OSError:
        return False
    return any(m in text for m in MARKERS)


def _candidate_configs():
    """各 agent 常见的 MCP 配置落点。"""
    home = Path.home()
    cwd = Path.cwd()
    codex_home = Path(os.environ.get("CODEX_HOME", home / ".codex"))
    appdata = os.environ.get("APPDATA", "")

    cands = [
        # Codex
        codex_home / "config.toml",
        home / ".codex" / "config.toml",
        # Claude Code / 通用
        home / ".claude.json",
        home / ".claude" / "mcp.json",
        home / ".claude" / "settings.json",
        home / ".agents" / "mcp.json",
        # WorkBuddy
        home / ".workbuddy" / "mcp.json",
        home / ".config" / "mcp" / "config.json",
        cwd / ".mcp.json",
        cwd / "mcp.json",
        cwd / ".cursor" / "mcp.json",
        cwd / ".vscode" / "mcp.json",
        # Claude Desktop
        home / "Library" / "Application Support" / "Claude" / "claude_desktop_config.json",
        Path(appdata) / "Claude" / "claude_desktop_config.json" if appdata else None,
    ]
    # 去重且保持顺序
    seen, uniq = set(), []
    for c in cands:
        if c is None:
            continue
        key = str(c)
        if key not in seen:
            seen.add(key)
            uniq.append(c)
    return uniq


def check_mcp():
    """返回 (可用?, 证据列表)。"""
    evidence = []

    for var in ("SORFTIME_MCP_KEY", "SORFTIME_MCP_URL"):
        if os.environ.get(var, "").strip():
            evidence.append(f"env:{var}")

    for cfg in _candidate_configs():
        if _file_mentions_sorftime(cfg):
            evidence.append(f"config:{cfg}")

    return bool(evidence), evidence


# ---------------------------------------------------------------- CLI 检测

def check_cli():
    """返回 (可用?, 证据列表)。"""
    evidence = []

    exe = shutil.which("sorftime")
    if not exe:
        return False, []
    evidence.append(f"command:{exe}")

    # 已登录？whoami 返回 0 即可（不消耗额度）
    try:
        r = subprocess.run(["sorftime", "whoami"], capture_output=True,
                           text=True, timeout=15)
        if r.returncode == 0 and "Account-SK" in (r.stdout + r.stderr):
            evidence.append("whoami:ok")
        elif r.returncode == 0:
            evidence.append("whoami:ok-no-profile")
    except (OSError, subprocess.SubprocessError):
        pass

    cfg = Path.home() / ".sorftime" / "config.json"
    if _readable(cfg):
        try:
            data = json.loads(cfg.read_text(encoding="utf-8"))
            if data.get("profiles"):
                evidence.append(f"config:{cfg}({len(data['profiles'])} profiles)")
        except (OSError, json.JSONDecodeError):
            evidence.append(f"config:{cfg}")

    # 有命令且能读到凭证才算可用
    usable = any(e.startswith("whoami:ok") for e in evidence) or any(
        e.startswith("config:") for e in evidence)
    return usable, evidence


# ---------------------------------------------------------------- 主流程

def main():
    quiet = "--quiet" in sys.argv or "-q" in sys.argv
    skip_quota = "--no-quota" in sys.argv

    mcp_ok, mcp_ev = check_mcp()
    cli_ok, cli_ev = check_cli()
    url = signup_url()
    promo = promo_code()
    promo_enabled = bool(url)
    promo_txt = f"，优惠码：{promo}" if promo else ""
    setup_hint = f"请先开通账号（含 7 天试用{promo_txt}），入口：\n{url}\n"
    topup_hint = f"请先充值/续期{promo_txt}，入口：\n{url}"

    quota = {"checked": False, "reason": "未装配任何通道"}
    if cli_ok and not skip_quota:
        quota = check_quota()

    setup_required = not (mcp_ok or cli_ok)
    quota_exhausted = bool(quota.get("checked")) and quota.get("ok") is False

    if setup_required:
        channel = None
        head = "【未装配】当前 agent 还没有检测到任何 Sorftime 通道（MCP 和 CLI 都没有）。\n"
        tail = ("拿到 Account-SK 后二选一：\n"
                "  MCP：见 shared/mcp-setup.md\n"
                "  CLI：npm install -g sorftime-cli && sorftime add default <Account-SK>")
        message = (head + setup_hint + tail
                   if promo_enabled else
                   head + "请先开通 Sorftime 账号并装配通道。\n" + tail)
    elif quota_exhausted:
        channel = "mcp" if mcp_ok else "cli"
        detail = []
        if quota.get("requests_left") is not None:
            detail.append(f"剩余请求 {quota['requests_left']}")
        if quota.get("coins") is not None:
            detail.append(f"剩余金币 {quota['coins']}")
        base = ("【额度已用尽】通道已装配，但账号额度不足"
                + (f"（{'、'.join(detail)}）" if detail else "")
                + "。\n")
        message = (base + topup_hint if promo_enabled
                   else base + "请先充值或续期后重试。")
    elif mcp_ok and cli_ok:
        channel, message = "mcp", "MCP+CLI 均可用；默认 MCP，批量/监控类任务请切 CLI"
    elif mcp_ok:
        channel, message = "mcp", "仅 MCP 通道可用"
    else:
        channel, message = "cli", "仅 CLI 通道可用；批量与监控任务不受影响"

    result = {
        "mcp_available": mcp_ok,
        "cli_available": cli_ok,
        "recommended_channel": channel,
        "setup_required": setup_required,
        "quota_exhausted": quota_exhausted,
        "quota": quota,
        "signup_url": url,
        "promo_code": promo,
        "promo_enabled": promo_enabled,
        "action_required": ("setup" if setup_required
                            else "topup" if quota_exhausted else None),
        "evidence": {"mcp": mcp_ev, "cli": cli_ev},
        "message": message,
    }

    if quiet:
        print("setup" if setup_required else "topup" if quota_exhausted else (channel or "none"))
        sys.exit(1 if (setup_required or quota_exhausted) else 0)

    ok = not (setup_required or quota_exhausted)
    stream = sys.stdout if ok else sys.stderr
    print(json.dumps(result, ensure_ascii=False, indent=2), file=stream)
    if not ok:
        print(message, file=sys.stderr)
    sys.exit(0 if ok else 1)


if __name__ == "__main__":
    main()
