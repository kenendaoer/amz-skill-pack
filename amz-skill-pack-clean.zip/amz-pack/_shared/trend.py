#!/usr/bin/env python3
"""类目趋势的「正确读法」工具（口径逻辑见 amzdata.py / DATA-CONTRACT.md）。

为什么需要它：
    `CategoryTrend` 返回的最后一个月是**当月，数据还没走完**。
    直接拿「第一个月 vs 最后一个月」算涨跌，会把任何类目都算成暴跌
    （实测：真实同比 +0.7%，首末对比算成 −59.1%）。

用法：
    python3 scripts/trend.py <nodeId> [--index 0] [--domain 1] [--json]

常用 trendIndex：0=销量 3=均价 4=平均评论数 7=3月新品份额 34=Top10品牌垄断
"""

import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import amzdata  # noqa: E402


def main():
    if len(sys.argv) < 2:
        print(__doc__)
        sys.exit(3)
    node = sys.argv[1]
    index, domain, as_json = 0, 1, "--json" in sys.argv
    for i, a in enumerate(sys.argv):
        if a == "--index" and i + 1 < len(sys.argv):
            index = int(sys.argv[i + 1])
        if a == "--domain" and i + 1 < len(sys.argv):
            domain = int(sys.argv[i + 1])

    try:
        res = amzdata.call("CategoryTrend", {"nodeId": str(node), "trendIndex": index}, domain)
    except amzdata.DataError as e:
        print(f"❌ {e}")
        sys.exit(1)

    if res["code"] not in (0, None):
        print(f"❌ CategoryTrend 返回 Code={res['code']} {res['message']}")
        sys.exit(1)

    series = amzdata.series_of(res)
    trend = amzdata.safe_trend(series)

    if as_json:
        print(json.dumps({"node": node, "index": index, **trend}, ensure_ascii=False, indent=2))
        sys.exit(0 if trend.get("ok") else 1)

    if not trend.get("ok"):
        print(f"❌ {trend.get('reason')}")
        for w in trend.get("warnings", []):
            print(f"   ⚠️  {w}")
        sys.exit(1)

    print(f"类目趋势（NodeId {node}，trendIndex {index}）")
    print(f"  有效数据点 {trend['points']} 个月")
    for w in trend["warnings"]:
        print(f"  ⚠️  {w}")
    print()
    print(f"  ⚠️  错误读法（首末直接对比）：{trend['naive_first_vs_last_pct']:+.1f}%  ← 别用这个")
    if trend["yoy_pct"] is not None:
        print(f"  ✅ 正确读法（同比 {trend['yoy_base_month']} → {trend['last_full_month']}）："
              f"{trend['yoy_pct']:+.1f}%")
    if trend["mid_term_pct"] is not None:
        print(f"  ✅ 中期趋势（近 12 完整月 vs 前 12 月）：{trend['mid_term_pct']:+.1f}%")
    print(f"  峰值 {trend['peak'][0]}（{trend['peak'][1]:,.0f}）／"
          f"谷值 {trend['trough'][0]}（{trend['trough'][1]:,.0f}）"
          + (f"　峰谷比 {trend['peak_trough_ratio']:.1f}x" if trend["peak_trough_ratio"] else ""))
    print()
    print(f"  结论：{amzdata.lifecycle(trend)}")


if __name__ == "__main__":
    main()
