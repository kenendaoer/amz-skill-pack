#!/usr/bin/env bash
# scripts/gen-image.sh — 可移植的「生图通道」封装（amz-image-creator 用）
#
# 为什么需要它：图片最终要渲染成 PNG，但每台机器的生图方式不同。
# 这个脚本把「用哪个生图服务」变成可配置项，而不是写死在技能里。
#
# 优先级（命中即用）：
#   1. 环境变量 AMZ_IMAGE_CMD      —— 你的生图命令，例：export AMZ_IMAGE_CMD="my-img"
#   2. 环境变量 IMAGE_CMD          —— 同上，兼容旧写法
#   3. ~/.codex/scripts/gen-image.sh —— 若已存在的工作台生图脚本，直接转交给它
#   4. 都没有 → 保存提示词并退出 2（技能退化为「只出提示词方案」）
#
# 自定义命令约定：从 stdin 读提示词，接受 --out <file> [--size WxH]
#
# Usage:
#   scripts/gen-image.sh --prompt "<提示词>" --out <输出.png> [--size 1024x1024]
#   scripts/gen-image.sh --prompt-file <提示词.txt> --out <输出.png>

set -uo pipefail

usage() {
  cat >&2 <<'EOF'
Usage: scripts/gen-image.sh --prompt <text> --out <file.png> [--size WxH]
       scripts/gen-image.sh --prompt-file <file.txt> --out <file.png>

本脚本本身不生成图片，而是把请求转交给你配置的生图通道：
    export AMZ_IMAGE_CMD="你的生图命令"     # 提示词从 stdin 读，支持 --out / --size
    # 或放置工作台脚本到 ~/.codex/scripts/gen-image.sh

未配置时退出码 2，调用方应退化为「输出完整提示词 + 尺寸/风格方案」，由用户手动生图。
EOF
}

PROMPT=""
PROMPT_FILE=""
OUT=""
SIZE=""

while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    --prompt)      PROMPT="${2:-}"; shift 2 ;;
    --prompt-file) PROMPT_FILE="${2:-}"; shift 2 ;;
    --out|-o)      OUT="${2:-}"; shift 2 ;;
    --size)        SIZE="${2:-}"; shift 2 ;;
    *) echo "[gen-image.sh] Unknown option: $1" >&2; usage; exit 3 ;;
  esac
done

[ -z "$OUT" ] && { echo "[gen-image.sh] 缺少 --out 输出路径" >&2; exit 3; }

if [ -z "$PROMPT" ] && [ -n "$PROMPT_FILE" ]; then
  [ -r "$PROMPT_FILE" ] || { echo "[gen-image.sh] 读不到提示词文件：$PROMPT_FILE" >&2; exit 3; }
  PROMPT=$(cat "$PROMPT_FILE")
fi
[ -z "$PROMPT" ] && { echo "[gen-image.sh] 缺少 --prompt 或 --prompt-file" >&2; exit 3; }

mkdir -p "$(dirname "$OUT")"

delegate() {
  local cmd="$1"
  echo "[gen-image.sh] 通过自定义通道生成：$cmd" >&2
  if [ -n "$SIZE" ]; then
    printf '%s' "$PROMPT" | $cmd --out "$OUT" --size "$SIZE"
  else
    printf '%s' "$PROMPT" | $cmd --out "$OUT"
  fi
  local rc=$?
  if [ $rc -eq 0 ] && [ -f "$OUT" ]; then
    echo "[gen-image.sh] 已生成：$OUT" >&2
    exit 0
  fi
  echo "[gen-image.sh] 自定义通道失败 (exit=$rc)" >&2
  exit 4
}

[ -n "${AMZ_IMAGE_CMD:-}" ] && delegate "$AMZ_IMAGE_CMD"
[ -n "${IMAGE_CMD:-}" ] && delegate "$IMAGE_CMD"

LEGACY="$HOME/.codex/scripts/gen-image.sh"
if [ -x "$LEGACY" ]; then
  echo "[gen-image.sh] 转交工作台生图脚本：$LEGACY" >&2
  if [ -n "$SIZE" ]; then
    exec "$LEGACY" --prompt "$PROMPT" --out "$OUT" --size "$SIZE"
  else
    exec "$LEGACY" --prompt "$PROMPT" --out "$OUT"
  fi
fi

PROMPT_TXT="${OUT%.*}.prompt.txt"
printf '%s\n' "$PROMPT" > "$PROMPT_TXT"
cat >&2 <<EOF
[gen-image.sh] 未配置生图通道（退出码 2）。

不影响使用：技能会改为输出「完整生图提示词 + 尺寸/场景方案」，
复制到任意生图工具（GPT-Image / 即梦 / Midjourney / 内部服务）即可出图。

想让它自动出图，任选一种：
  1) export AMZ_IMAGE_CMD="你的生图命令"
  2) 放置工作台脚本到 ~/.codex/scripts/gen-image.sh

提示词已保存：$PROMPT_TXT
EOF
exit 2
