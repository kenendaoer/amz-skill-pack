#!/usr/bin/env bash
# scripts/cli_call.sh — Sorftime CLI 单端点调用封装（amz-* 技能通用）
#
# 特点：不依赖 jq / python3（两者都没有时也能正常返回 JSON 与退出码）。
#
# Usage:
#   scripts/cli_call.sh <Endpoint> '<json-params>' [--domain <N>] [--profile <name>] [--no-jq] [--raw] [--retries <N>]
#
# Exit codes:
#   0  API code=0
#   2  API code≠0 (business error)
#   3  输入/端点错误（含端点不存在 404）
#   4  Network / CLI exception

set -uo pipefail

# ---------- 开通/充值链接（唯一来源：同目录 signup.env） ----------
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 优先级：环境变量 > 本机个人配置(~/.sorftime/signup.env) > 随包配置(scripts/signup.env)
# 值为 off/none/空 表示关闭推广链接（只提示、不给链接）
read_signup() {
  local f="$1"
  [ -r "$f" ] || return 1
  local v
  v=$(grep -m1 '^SORFTIME_SIGNUP_URL=' "$f" 2>/dev/null | cut -d= -f2- | tr -d '"'"'" | tr -d ' ')
  [ -n "$v" ] && { printf '%s' "$v"; return 0; }
  return 2   # 文件存在但值为空 → 明确关闭
}

if [ -n "${SORFTIME_SIGNUP_URL+x}" ]; then
  SIGNUP_URL="$SORFTIME_SIGNUP_URL"
else
  SIGNUP_URL=""
  for f in "$HOME/.sorftime/signup.env" "$HOME/.config/sorftime/signup.env" "$SCRIPT_DIR/signup.env"; do
    if [ -r "$f" ]; then
      cand=$(read_signup "$f") || true
      case "$f" in
        "$HOME/.sorftime/signup.env"|"$HOME/.config/sorftime/signup.env")
          SIGNUP_URL="$cand"; break ;;      # 个人配置优先，命中即停（空值=关闭）
        *) [ -n "$SIGNUP_URL" ] || SIGNUP_URL="$cand" ;;
      esac
    fi
  done
fi

case "$(printf '%s' "$SIGNUP_URL" | tr 'A-Z' 'a-z')" in
  ""|off|none|no|-) SIGNUP_URL="" ;;
esac

# 优惠码（唯一来源：同目录 signup.env 的 SORFTIME_PROMO_CODE）
PROMO_CODE=""
if [ -n "${SORFTIME_PROMO_CODE+x}" ]; then
  PROMO_CODE="$SORFTIME_PROMO_CODE"
else
  for f in "$HOME/.sorftime/signup.env" "$HOME/.config/sorftime/signup.env" "$SCRIPT_DIR/signup.env"; do
    [ -r "$f" ] || continue
    PROMO_CODE=$(grep -m1 '^SORFTIME_PROMO_CODE=' "$f" 2>/dev/null | cut -d= -f2- | tr -d '"'"'" | tr -d ' ')
    [ -n "$PROMO_CODE" ] && break
  done
fi

# 需要提示开通/充值时用的后缀（未开启推广则只提示）
promo_hint() {
  if [ -n "$SIGNUP_URL" ]; then
    if [ -n "$PROMO_CODE" ]; then
      echo "请从这里开通或充值（优惠码：${PROMO_CODE}）：${SIGNUP_URL}"
    else
      echo "请从这里开通或充值：${SIGNUP_URL}"
    fi
  else
    echo "请先开通账号或充值后重试。"
  fi
}

usage() {
  cat >&2 <<'EOF'
Usage: scripts/cli_call.sh <Endpoint> '<json-params>' [--domain <N>] [options]

Required:
  <Endpoint>           PascalCase endpoint name (e.g. ProductRequest, CategoryRequest)
  '<json-params>'      JSON string wrapped in single quotes; pass '' for no parameters

Options:
  --domain <N>         Site code (1=Amazon US, 2=UK, 3=DE, ... | Walmart 21 | 1688 601 | Shopee 201+)
  --profile <name>     Profile name (omit to use the current `sorftime use` profile)
  --no-jq              Do not pretty-print JSON
  --raw                Do not process at all
  --retries <N>        Retry times for network errors (default 1)
  -h, --help           Show this help

Exit codes:
  0  API code=0
  2  API code!=0 (business error)
  3  Bad input / unknown endpoint
  4  Network / CLI exception
EOF
}

ENDPOINT=""
JSON='{}'
DOMAIN="${SORFTIME_DEFAULT_DOMAIN:-1}"
PROFILE=""
USE_JQ=1
RAW=0
RETRIES=1

if [ $# -eq 0 ]; then usage; exit 3; fi

while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    --domain)  DOMAIN="${2:-1}"; shift 2 ;;
    --profile) PROFILE="${2:-}"; shift 2 ;;
    --no-jq)   USE_JQ=0; shift ;;
    --raw)     RAW=1; USE_JQ=0; shift ;;
    --retries) RETRIES="${2:-1}"; shift 2 ;;
    --*)       echo "[cli_call.sh] Unknown option: $1" >&2; usage; exit 3 ;;
    *)
      if [ -z "$ENDPOINT" ]; then ENDPOINT="$1"; shift
      elif [ "$JSON" = "{}" ]; then JSON="$1"; shift
      else echo "[cli_call.sh] Unexpected positional parameter: $1" >&2; usage; exit 3
      fi
      ;;
  esac
done

[ -z "$ENDPOINT" ] && { echo "[cli_call.sh] Missing <Endpoint>" >&2; exit 3; }

if ! printf '%s' "$ENDPOINT" | grep -Eq '^[A-Z][A-Za-z0-9]+$'; then
  echo "[cli_call.sh] Endpoint '$ENDPOINT' is not PascalCase; check spelling in references/" >&2
  exit 3
fi

if ! command -v sorftime >/dev/null 2>&1; then
  echo "[cli_call.sh] 【未装配】本机没有 sorftime CLI，也没有可用的 MCP 通道。" >&2
  echo "[cli_call.sh] 装配方式：npm install -g sorftime-cli && sorftime add default <Account-SK>" >&2
  echo "[cli_call.sh] $(promo_hint)" >&2
  exit 4
fi

CMD=(sorftime api "$ENDPOINT" "$JSON" --domain "$DOMAIN")
[ -n "$PROFILE" ] && CMD+=(--profile "$PROFILE")

attempt=0
while [ "$attempt" -lt "$RETRIES" ]; do
  attempt=$((attempt + 1))

  RAW_OUT=$("${CMD[@]}" 2>&1)
  RAW_RC=$?

  if [ "$RAW_RC" -ne 0 ]; then
    case "$RAW_OUT" in
      *"status code 404"*)
        echo "[cli_call.sh] 端点不存在：${ENDPOINT}（HTTP 404，未消耗额度）。检查拼写与平台归属。" >&2
        echo "[cli_call.sh] 提示：--domain 传错也会 401/404（Amazon 1-14 / Walmart 21 / 1688 601 / Shopee 201+）。" >&2
        exit 3 ;;
    esac
    if [ "$attempt" -lt "$RETRIES" ]; then sleep "$attempt"; continue; fi
    case "$RAW_OUT" in
      *401*|*403*|*认证*|*密钥*|*ccount-SK*|*余额*|*不足*|*uota*|*redit*)
        echo "[cli_call.sh] 【未装配或额度不足】凭证无效 / 未开通 / 额度已用尽。" >&2
        echo "[cli_call.sh] $(promo_hint)" >&2 ;;
    esac
    echo "[cli_call.sh] CLI exit=${RAW_RC}" >&2
    echo "$RAW_OUT" >&2
    exit 4
  fi

  if [ "$RAW" -eq 1 ]; then echo "$RAW_OUT"; exit 0; fi

  CLEAN=$(printf '%s\n' "$RAW_OUT" \
    | sed $'s/\033\\[[0-9;]*[mK]//g' \
    | sed -n '/^[[:space:]]*[{[]/,$p')
  [ -z "$CLEAN" ] && CLEAN="$RAW_OUT"

  CODE=$(printf '%s' "$CLEAN" | grep -o '"Code"[[:space:]]*:[[:space:]]*-\{0,1\}[0-9]*' | head -1 | grep -o '\-\{0,1\}[0-9]*$' || true)
  MSG=$(printf '%s' "$CLEAN" | grep -o '"Message"[[:space:]]*:[[:space:]]*"[^"]*"' | head -1 | sed 's/.*:[[:space:]]*"//; s/"$//' || true)

  if [ "$USE_JQ" -eq 1 ] && command -v jq >/dev/null 2>&1; then
    printf '%s\n' "$CLEAN" | jq . 2>/dev/null || printf '%s\n' "$CLEAN"
  else
    printf '%s\n' "$CLEAN"
  fi

  if [ -n "$CODE" ] && [ "$CODE" != "0" ]; then
    case "$CODE" in
      11) echo "[cli_call.sh] ${ENDPOINT}: 无数据（Code=11），非错误，按空结果处理。" >&2 ;;
      99) echo "[cli_call.sh] ${ENDPOINT}: 异步任务已受理（Code=99），稍后查询结果。" >&2 ;;
      694) echo "[cli_call.sh] ${ENDPOINT}: 额度不足（Code=694）。$(promo_hint)" >&2 ;;
      401) echo "[cli_call.sh] ${ENDPOINT}: 该 API 不可用（Code=401），优先检查 --domain 是否为该平台。" >&2 ;;
      *)   echo "[cli_call.sh] ${ENDPOINT} business error code=${CODE} message=${MSG}" >&2 ;;
    esac
    # 额度/凭证类问题统一再提示一次开通入口（694/4 已在上面的 case 里提示过，避免重复）
    case "$CODE" in
      694|4) ;;
      *) case "$MSG" in
           *余额*|*不足*|*nsufficient*|*uota*|*redit*)
             echo "[cli_call.sh] 【额度/凭证问题】$(promo_hint)" >&2 ;;
         esac ;;
    esac
    exit 2
  fi

  exit 0
done
