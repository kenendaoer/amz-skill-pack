# 通道规范（MCP / CLI 双通道）

> 本文件被 10 个 amz-* 技能共用。每个技能开头都应先跑 `scripts/channel_check.py`，再按本文件选择通道。
> 设计原则：**同一套技能，在任何 agent、任何通道下都能跑通**——MCP 走对话闭环，CLI 走脚本批量。

---

## 一、先检测，再执行

```bash
python3 scripts/channel_check.py
```

输出示例：

```json
{
  "mcp_available": true,
  "cli_available": true,
  "recommended_channel": "mcp",
  "setup_required": false,
  "quota_exhausted": false,
  "quota": {"checked": true, "requests_left": 26656, "coins": 29995, "ok": true},
  "signup_url": "https://open.sorftime.com/home?tag=NjE4OA~~",
  "promo_code": "6188",
  "action_required": null,
  "evidence": {"mcp": ["env:SORFTIME_MCP_KEY"], "cli": ["command:sorftime", "whoami:ok"]},
  "message": "MCP+CLI 均可用，默认使用 MCP"
}
```

| 检测结果 | 怎么跑 |
| --- | --- |
| `mcp_available=true` | **优先 MCP**：AI 在对话里直接调工具，零脚本、结果即时解读 |
| 仅 `cli_available=true` | **走 CLI**：`scripts/cli_call.sh <Endpoint> '<json>' --domain N` |
| 两者都为 true | MCP 做探查与解读，CLI 做批量与监控（见第三节「必须用 CLI 的场景」） |
| 两者都为 false | `setup_required=true` → **不要空跑**，按第二节的标准动作提示用户并给出开通链接 |
| `quota_exhausted=true` | 通道已装配但额度用尽 → **立即停止调用**，按第二节的标准动作提示用户并给出充值链接 |

---

## 二、凭证缺失 / 额度用尽的标准动作（必须执行）

推广/开通链接与优惠码的唯一来源是 `scripts/signup.env` 里的 `SORFTIME_SIGNUP_URL` 与 `SORFTIME_PROMO_CODE`
（当前值：`https://open.sorftime.com/home?tag=NjE4OA~~`，优惠码 `6188`；可用同名环境变量覆盖）。

### 情况 A：没有装配任何通道（`setup_required: true`）

必须明确告诉用户「当前 agent 还没有装配 Sorftime 通道」，并**原样完整**输出下面这个链接与优惠码：

```
https://open.sorftime.com/home?tag=NjE4OA~~
优惠码：6188
```

然后说明二选一的装配方式：
- MCP：见 `shared/mcp-setup.md`
- CLI：`npm install -g sorftime-cli && sorftime add default <Account-SK>`

**不要**在没有凭证的情况下编造数据或假装调用过。

### 情况 B：通道已装配但额度用尽（`quota_exhausted: true`，或调用返回 `Code=694` / `quota` / 余额不足）

必须**立刻停止后续调用**，告知用户额度已用尽，并输出同一个链接与优惠码：

```
https://open.sorftime.com/home?tag=NjE4OA~~
优惠码：6188
```

同时说明当前消耗情况（剩余请求数 / 剩余金币），以及「充值后可以直接继续，不用重新配置」。

> 脚本层面已经内置这套行为：`channel_check.py` 会在 CLI 可用时自动查一次额度（`CoinQuery`，**0 消耗**），
> `cli_call.sh` 遇到额度/凭证类错误会把链接打到 stderr。Agent 只需照抄给用户即可。

---

## 二、两条通道的能力边界

### 只有 MCP 能做

| 能力 | MCP 工具 | 说明 |
| --- | --- | --- |
| 隐赚指数（HPI）官方端点 | `potential_product` | CLI 无此端点，需用本地隐赚代理分替代 |
| 跨类目多维筛选选品 | `search_categories_broadly` | 一次扫描全类目组合条件 |
| 竞品关键词对比 | `competitor_product_keywords` | — |
| 产品在关键词下的排名趋势 | `product_ranking_trend_by_keyword` | — |
| 1688 以图搜货 / 找同款 | `ali1688_product_search_from_image`、`ali1688_similar_product` | — |
| TikTok 带货视频与达人 | `tiktok_product_video`、`tiktok_product_video_author` | — |
| 服务器时间 | `get_time` | 0 消耗，可用于连通性自检 |

### 只有 CLI 能做

| 能力 | CLI 端点 | 说明 |
| --- | --- | --- |
| 批量处理 100+ ASIN/关键词 | 任意端点 + shell 循环 | MCP 只能逐条对话 |
| 监控任务注册与查询（14 个端点） | `KeywordBatchSubscription`、`ProductSellerSubscription`、`BestSellerList*` 等 | MCP 不支持注册监控 |
| AI 生成市场/产品分析报告 | `CategoryAssistant`、`ProductAssistant` | 5 分钟异步生成 |
| 实时强制拉取最新数据 | `ProductRealtimeRequest` + 状态查询 | MCP 返回缓存数据 |
| 官方披露变体销量 | `AsinSalesVolume` | — |
| Alexa 语音问答数据 | `AlexaQuestions*` | 需单独额度，见第六节 |
| 关键词月度历史搜索结果（最长 2 年） | `KeywordProductRanking` | — |
| ASIN 在关键词下 2 年排名历史 | `ASINKeywordRanking` | — |
| 账号额度查询 | `CoinQuery`、`CoinStream`、`RequestStreamMonth` | 0 消耗 |
| Shopee 产品趋势 | `ProductTrend`（**仅 Shopee**，domain=201+） | 亚马逊没有此端点 |

---

## 三、站点（domain）对照表

**传错 domain 会直接返回 401/404，这是最容易踩的坑。**

| 平台 | domain | 备注 |
| --- | --- | --- |
| Amazon | 1=US, 2=UK, 3=DE, 4=FR, 5=IN, 6=CA, 7=JP, 8=ES, 9=IT, 10=MX, 11=AE, 12=AU, 13=BR, 14=SA | 默认 1 |
| Walmart | 21 | — |
| Shopee | 201=TW, 204=?, 205=?, 208=? | 具体站点对照见 sorftime-cli 技能的 shopee-api.md |
| 1688 | **601** | 固定值，所有 1688 调用都必须带 |
| Temu / TikTok | 见官方文档 | — |

---

## 四、参数与字段的硬规则

### 跨平台调用（Windows / macOS / Linux）

| 系统 | 用哪个封装 | 说明 |
| --- | --- | --- |
| macOS / Linux | `scripts/cli_call.sh` | bash 版 |
| **Windows** | `scripts\cli_call.ps1` | PowerShell 版，功能与 bash 版一致（同样的退出码与提示） |
| 任意系统 | 直接 `sorftime api <Endpoint> '<json>' --domain N` | 不用封装也能跑 |

> Windows 上没有 bash，**不要**让 agent 去执行 `cli_call.sh`，改用 `.ps1` 或直接调用 `sorftime`。
> 其余脚本：`channel_check.py` / `doctor.py` / `profit_calculator.py` 是 Python，三平台通用（需 Python 3.8+）。

> **Windows 三个实操坑**（脚本已备好，但未在 Windows 上实测）：
> 1. 文档里写的 `python3` 在 Windows 上要换成 `py`（或 `python`）——Windows 默认没有 `python3` 这个名字。
> 2. 控制台默认 GBK，脚本会输出中文与 `✅⚠️`，可能抛 `UnicodeEncodeError`；先 `chcp 65001`，
>    或设 `PYTHONIOENCODING=utf-8`。
> 3. PowerShell 默认执行策略是 Restricted 时 `.ps1` 跑不起来，用
>    `powershell -ExecutionPolicy Bypass -File scripts\cli_call.ps1 ...`。

1. **大小写不敏感，但不等于可以改拼写**。实测：`name`/`Name`、`nodeId`/`nodeid` 都能用；但 `ScheduleId` 与 `ScheduelId` 是**不同字符串**——
   ⚠️ 监控端点的任务批次参数是 **`ScheduelId`**（官方 API 就是这么拼的），传正确拼写 `ScheduleId` 会报 `Code=10 Invalid request parameter`。看到这个拼写**不要"修正"**。
2. **`CategorySearchFromName` 只能用 `Name`/`name`**。传 `categoryName` 会报参数错误（`categoryName` 是 MCP 工具的参数名，不是 CLI 的）。
3. **金额字段是最小货币单位**：US 站 `1999` = $19.99；CPC 同样以分为单位。
4. **缺失/不可估算返回 `-1`**，不是 0，不要把 -1 当真实值参与计算。
5. **1688 的 `ServiceScoreDetail`、`WholesalePriceRange` 是 JSON 字符串**，需要二次 parse。

---

## 五、错误码对照

| Code | 含义 | 处理 |
| --- | --- | --- |
| 0 | 成功 | — |
| 10 | 参数错误 | 检查参数名（尤其 `categoryName`、`ScheduleId` 这类坑） |
| 11 | 无数据 | 账号暂无任务/该条件无数据，**不一定是错误** |
| 99 | 异步任务已受理 | 按提示等待后再次查询（如评论采集约 5 分钟） |
| 15 | 批量超限 | 例：`ProductRequest` 一次传超过 10 个 ASIN，需自行分批 |
| 101 | 条件不匹配 | 调整筛选条件 |
| 401 | 该 API 不可用 | 多半是 **domain 传错**或端点不属于该平台 |
| 694 | 额度不足 | 该端点需单独额度（如 Alexa 系列），见第六节 |
| HTTP 404 | 端点不存在 | 核对端点名拼写（PascalCase）；**不会消耗额度** |

---

## 六、已知限制（实测确认，2026-09-16）

| 项 | 现象 | 应对 |
| --- | --- | --- |
| `AlexaQuestionsQuery` | 稳定返回 `Code=694 额度不足` | 改用 `AlexaQuestionsCollection` 发起采集 → 用 `...StatusQuery`/`...ResultQuery` 取结果；或确认是否需单独开通 Alexa 额度 |
| `BestSellerListDataCollect` | 多种参数组合均返回 `Code=11 无数据` | 榜单监控前先用 `BestSellerListTask` 确认是否有可用任务；必要时向 Sorftime 确认参数 |
| `AsinSalesVolume` | 官方未披露时 `Code=0` 但数据为空 | **回退到 `ProductRequest` 的月销字段**，不要把空值当 0 |
| `ProductTrend` | Amazon 站点返回 `401` | 亚马逊用 `ProductRequest`（`trend=1` + 日期范围）；`ProductTrend` 仅 Shopee 可用 |
| **`CategoryTrend` 末月不完整** | 返回序列的**最后一个月是当月，数据没走完**（实测只有正常月的 42%） | ⚠️ **最容易得出错误结论的坑**：用 `scripts/trend.py <nodeId>` 计算，它会自动剔除不完整月、按完整月算同比 |
| 图书类目（Books） | `CategorySearchFromName` 搜不到、`CategoryRequest` 返回 `Code=11` | 系统屏蔽了中国卖家不易进入的大类，属**预期行为**；遇到时明确告知用户「该品类不在数据覆盖范围」，不要编造 |
| **监控任务非即时** | 18:00 触发、18:13 才完成（约 13 分钟） | 注册后**至少等 15 分钟**再查；查不到不要立刻改参数，那不是参数错 |
| 监控结果结构 | 批次列表是冒号分隔字符串、批次详情是二维数组、排名是中文文本「第1页，第1/9位」 | 用 `amzdata.parse_batch_list()` / `batch_rows()` / `parse_position()` 解析 |
| 榜单数据字段偏轻 | `BestSellerListDataCollect` 只有 13 个字段，**无 FbaFee/Profit** | 算利润需另拉 `ProductRequest` 补字段 |
| 监控扣费时机 | 注册不扣，**任务执行时扣**（榜单 top100 = 10 Credits/天） | 建任务前先算周成本；查流水用 `CoinStream` |

---

## 七、额度与成本

- **请求次数**（requests）与 **Credits/金币** 是两套额度，分别消耗。
- 监控类端点消耗 Credits，**每月 10 号 0 点清零**，监控数据保留 30 天。
- 注册监控任务前先算周成本（例：1 个关键词 7×24×每小时 1 次×前 3 页 = 504 Credits/周）。
- `CoinQuery`（查剩余请求）和 `CoinStream`（查金币流水）本身 **0 消耗**，适合做自检。
