#!/usr/bin/env python3
"""口径守门层（data contract）—— 所有派生指标都必须经过它。

背景：Sorftime 的原始返回里有几类「看起来是数字、其实不能直接用」的字段。
任何一处处理错，结论都可能反向（实测：真实同比 +0.7% 被算成 −59.1%）。

本模块把「原始数据 → 可用于判断的指标」这一步标准化，规则见 shared/DATA-CONTRACT.md。
"""

import json
import re
import subprocess
from datetime import date, datetime, timedelta

# ---------- 已知的「最小货币单位」字段（返回值 ÷100 = 美元） ----------
MONEY_FIELDS = {
    "SalesPrice", "Price", "ListPrice", "FbaFee", "PlatformFee", "Profit",
    "ShipCost", "Coupon", "ExtraSavings", "AsinPrice", "WholesalePrice",
}
# 需要按克/厘米理解，而不是磅/英寸
WEIGHT_FIELDS = {"Weight"}          # 克
SIZE_FIELDS = {"Size"}              # cm [最长,次长,最短]
# 缺失值标记
MISSING = (-1, None, "", "N/A", "na", "null")


class DataError(Exception):
    """数据不可用时抛出，附带可读原因。"""


# ---------------------------------------------------------------- 基础转换
def money(v):
    """最小货币单位 → 美元。缺失/负数返回 None。"""
    if v in MISSING:
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    if x < 0:
        return None
    return round(x / 100, 2)


def count(v):
    """计数类字段（评论数、销量、变体数）。负值/缺失返回 None。"""
    if v in MISSING:
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return None if x < 0 else x


def weight_g(v):
    """重量统一为克（接口本身就是克，这里只做缺失处理）。"""
    return count(v)


def rate(v):
    """百分比字段（ProfitRate 已经是 73.83 这种百分数，不要 ×100）。"""
    return count(v)


def num_str(v):
    """字符串数字 → float。

    `AsinSalesVolume` 返回的是 `[['2026-09-15','2000','2'], ...]`——
    日期、销量、类型**全都是字符串**。直接参与算术会出错（'2000'*2 = '20002000'）。
    """
    if v in MISSING:
        return None
    try:
        return float(str(v).replace(",", "").strip())
    except (TypeError, ValueError):
        return None


def size_cm(v):
    """尺寸 → [最长, 次长, 最短]（cm）。

    实测返回是**单元素数组里塞了一个逗号串**：`['44.30,36.14,12.7']`。
    直接 `Size[0], Size[1], Size[2]` 会取到字符串然后越界。
    """
    if not v:
        return None
    raw = v[0] if isinstance(v, list) and v else v
    if not isinstance(raw, str):
        return None
    parts = [num_str(x) for x in raw.split(",")]
    parts = [p for p in parts if p is not None]
    return parts or None


def fba_parts(detail):
    """`FbaDetetail` → (配送费, 1-9月仓储, 10-12月仓储)，单位美元。

    实测样例：`[1369, '1-9:40', '10-12:101']` → 配送 $13.69 + 仓储 $0.40 / $1.01。
    ⚠️ `FbaDetetail[0]` **只是配送费**，不含仓储；FBA 总额请用 `FbaFee`。
    （本例 FbaFee=1409 = 1369 + 40）
    """
    if not isinstance(detail, list) or not detail:
        return None
    out = {"配送费": money(detail[0])}
    for item in detail[1:]:
        if isinstance(item, str) and ":" in item:
            k, val = item.split(":", 1)
            out[f"{k}月仓储"] = money(num_str(val))
    return out


def fba_total(item):
    """FBA 总费用（美元）：优先 FbaFee，缺失时用 FbaDetetail 推算。"""
    v = money(item.get("FbaFee"))
    if v is not None:
        return v
    parts = fba_parts(item.get("FbaDetetail"))
    if not parts:
        return None
    vals = [x for x in parts.values() if x is not None]
    return round(sum(vals), 2) if vals else None


def bsr_categories(item):
    """`BsrCategory` → [{'类目','NodeId','排名','日期'}, ...]。

    实测结构是**嵌套数组**：`[['Robotic Vacuums','3743561','125','20260916']]`
    （类目名、NodeId、排名、日期都是字符串）。想拿排名要取 [0][2]。
    """
    v = item.get("BsrCategory")
    if not isinstance(v, list):
        return []
    out = []
    for row in v:
        if isinstance(row, list) and len(row) >= 3:
            out.append({"类目": row[0], "NodeId": row[1],
                        "排名": num_str(row[2]), "日期": row[3] if len(row) > 3 else None})
    return out


def best_bsr_rank(item):
    """取最好的（数值最小的）子类目排名。"""
    ranks = [b["排名"] for b in bsr_categories(item) if b["排名"]]
    return min(ranks) if ranks else None


def history_window(today=None, span_days=20):
    """`CategoryRequest` 历史回溯的合法窗口。

    接口限制（实测报错原文）：
        supports data from 2 years ago to **7 days before the current date**,
        covering **3 to 40 days** of data
    参数名是 `queryStart` + **`queryDate`**——写 `queryEnd` 会直接 Code=10。
    返回 (queryStart, queryDate) 两个 yyyy-MM-dd 字符串。
    """
    today = today or date.today()
    if not 3 <= span_days <= 40:
        raise DataError("历史回溯跨度必须在 3–40 天之间")
    end = today - timedelta(days=7)             # 不能用最近 7 天
    start = end - timedelta(days=span_days)
    if (today - start).days > 730:
        raise DataError("历史回溯最长 2 年")
    return str(start), str(end)


def cpc_range(v):
    """`CpcRange` → (最低, 最高) 美元。

    实测返回是**二元数组**、且单位是分：`[102, 192]` → ($1.02, $1.92)。
    不要当字符串或美元用。
    """
    if not isinstance(v, list) or len(v) < 2:
        return None
    lo, hi = money(v[0]), money(v[1])
    return (lo, hi) if lo is not None else None


# 派生率字段：实测都是**百分数（0-100）**，不要再 ×100
RATE_FIELDS = ("SearchConversionRate", "ShareClickRate", "ShareConversionRate")


def rate_field(v):
    """读取百分数字段（原值即百分数，如 34.15 表示 34.15%）。"""
    return count(v)


def all_category_products(node_id, pages=3, domain=1, per_page_note=True):
    """翻页拉取类目热销品。

    ⚠️ **`CategoryProducts` 的 `range` 参数无效**（实测 range=100/500/2000 返回完全相同
    的 100 条），要拿更多数据只能**翻页**：每页 100 条，page=1/2/3 之间无重叠。
    文档里"range 可取 1000+"的说法是错的。

    返回去重后的产品列表。
    """
    out, seen = [], set()
    for page in range(1, pages + 1):
        res = call("CategoryProducts", {"nodeId": str(node_id), "page": page}, domain)
        if res["code"] not in (0, None):
            break
        items = products_of(res)
        if not items:
            break
        fresh = 0
        for it in items:
            key = it.get("Asin") or it.get("ASIN")
            if key and key not in seen:
                seen.add(key)
                out.append(it)
                fresh += 1
        if fresh == 0:
            break
    return out


def season_param(months):
    """构造 `peakSellingSeason` 参数值。

    实测：`"4,5"`、`"5"` 这类**逗号分隔的月份数字**是有效写法（在季节性类目上返回数据）。
    ⚠️ 但该端点**无数据时返回 `Code=11`**，这**不代表参数写错**——可能是该月确实没有匹配产品。
    所以：不要在非季节性类目上用它来判断"格式对不对"。
    """
    if isinstance(months, (list, tuple)):
        months = ",".join(str(int(m)) for m in months)
    return str(months)


def period_expr(days, times, frequency):
    """构造监控的 `period` 表达式。

    格式：`<星期>|<时段>|<频率>`，服务端会解析成
    `{"Day": "...", "Time": "...", "Frequency": "..."}`（实测存储格式）。
      - Day：1-7（1=周一），可逗号分隔，如 "1,2,3,4,5"
      - Time：1-6（每段 4 小时，北京时间：1=1-4点 … 6=21-0点）
      - Frequency：1=时段内 1 次，2=每小时 1 次，3=每 2 小时 1 次
    """
    if isinstance(days, (list, tuple)):
        days = ",".join(str(int(d)) for d in days)
    if isinstance(times, (list, tuple)):
        times = ",".join(str(int(t)) for t in times)
    return f"{days}|{times}|{frequency}"


# ---------------------------------------------------------------- 监控结果解析
def parse_coin_stream(data):
    """解析金币流水。

    实测 `CoinStream.Data` 是 `{'CoinStream': [12,'202609161800',-10,29985, 28,'202609161540',-5,29995]}`——
    **扁平数组，每 4 个元素一条记录**：`[类型, 时间(YYYYMMDDHHmm), 变动, 变动后余额]`。
    不是对象列表，直接迭代会拿到一堆散值。
    """
    if isinstance(data, dict):
        data = data.get("CoinStream")
    if not isinstance(data, list):
        return []
    out = []
    for i in range(0, len(data) - 3, 4):
        out.append({"类型": data[i], "时间": str(data[i + 1]),
                    "变动": data[i + 2], "余额": data[i + 3]})
    return out


def parse_request_stream(data):
    """解析请求量流水：`{'Purchase': [], 'Consume': [['202608', 3325], ['202609', 578]]}`。"""
    if not isinstance(data, dict):
        return {"Purchase": [], "Consume": []}
    return {"Purchase": data.get("Purchase") or [], "Consume": data.get("Consume") or []}


def parse_batch_list(data):
    """解析 `KeywordBatchScheduleList` 的执行批次。

    实测返回 `['202609161800:5a5067e878dc4a889d8ebcdbf79e6a9b:1:202609161813']`——
    **冒号分隔的字符串**：`执行时间:批次ID:状态:完成时间`。
    批次 ID 就是下游 `KeywordBatchScheduleDetail` 需要的 `ScheduelId`。
    """
    if not isinstance(data, list):
        return []
    out = []
    for item in data:
        if isinstance(item, str) and ":" in item:
            parts = item.split(":")
            out.append({"执行时间": parts[0],
                        "批次ID": parts[1] if len(parts) > 1 else None,
                        "状态": parts[2] if len(parts) > 2 else None,
                        "完成时间": parts[3] if len(parts) > 3 else None})
        elif isinstance(item, list) and item:
            out.append({"执行时间": item[0],
                        "批次ID": item[1] if len(item) > 1 else None})
    return out


_POS_RE = re.compile(r"第\s*(\d+)\s*页.*?第\s*(\d+)\s*/\s*(\d+)\s*位")


def parse_position(text):
    """解析监控结果里的排名位置文本。

    实测 `KeywordBatchScheduleDetail` 里给的是**中文文本**：`'第1页，第1/9位'`，
    要拿数字排名必须解析字符串。
    返回 {'页': 1, '序号': 1, '总数': 9}，无法解析时返回 None。
    """
    if not isinstance(text, str):
        return None
    m = _POS_RE.search(text)
    if not m:
        return None
    return {"页": int(m.group(1)), "序号": int(m.group(2)), "总数": int(m.group(3))}


def batch_rows(data):
    """`KeywordBatchScheduleDetail` 返回「数组的数组」，这里统一成字典列表。

    实测每行字段顺序（约 14 项）：
      [0] ASIN  [1] 主图  [2] 标题  [3] 曝光类型  [5] 位置文本（如「第1页，第1/9位」）
      [8] 评分  [9] 评论数  [10] 价格(分)  [12] 品牌  [13] 卖家ID
    ⚠️ 文档写的是「CSV 格式字符串数组」，实际是已解析的二维数组。
    """
    if not isinstance(data, list):
        return []
    out = []
    for row in data:
        if not isinstance(row, list):
            continue
        out.append({
            "ASIN": row[0] if len(row) > 0 else None,
            "主图": row[1] if len(row) > 1 else None,
            "标题": row[2] if len(row) > 2 else None,
            "曝光类型": row[3] if len(row) > 3 else None,
            "位置文本": row[5] if len(row) > 5 else None,
            "位置": parse_position(row[5]) if len(row) > 5 else None,
            "评分": rate_field(row[8]) if len(row) > 8 else None,
            "评论数": count(row[9]) if len(row) > 9 else None,
            "价格": money(row[10]) if len(row) > 10 else None,
            "品牌": row[12] if len(row) > 12 else None,
        })
    return out


def norm_product(item: dict) -> dict:
    """把一条产品记录规范化成「可以直接参与计算」的字典。"""
    out = {}
    for k, v in item.items():
        if k in MONEY_FIELDS:
            out[k] = money(v)
        elif k in ("Weight", "RatingsCount", "ListingSalesVolumeOfMonth",
                   "ListingSalesOfMonth", "VariationASINCount", "ReviewCount",
                   "Ratings", "OnlineDays", "SellerCount"):
            out[k] = count(v)
        else:
            out[k] = v
    # 需要二次拆解的字段
    out["Size_cm"] = size_cm(item.get("Size"))
    if item.get("FbaDetetail"):
        out["FbaParts"] = fba_parts(item["FbaDetetail"])
        out["FbaTotal"] = fba_total(item)
    if item.get("BsrCategory"):
        out["BsrBest"] = best_bsr_rank(item)
    return out


# ---------------------------------------------------------------- 接口调用
def call(endpoint, params=None, domain=1, timeout=120, profile=None):
    """调用 CLI 并按口径解析。

    返回 {"code", "message", "data", "request_left", "raw"}；
    code != 0 时不抛异常，由调用方决定（11=无数据、99=异步、694=额度…）。
    """
    cmd = ["sorftime", "api", endpoint, json.dumps(params or {}), "--domain", str(domain)]
    if profile:
        cmd += ["--profile", profile]
    try:
        r = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)
    except subprocess.TimeoutExpired:
        raise DataError(f"{endpoint} 调用超时")

    text = r.stdout + r.stderr
    if "status code 404" in text:
        raise DataError(f"{endpoint} 端点不存在（404）。检查拼写与端点归属的平台。")

    m = re.search(r"\{[\s\S]*\}", text)
    if not m:
        raise DataError(f"{endpoint} 未返回 JSON：{text.strip()[:120]}")
    obj = json.loads(m.group(0))
    return {
        "code": obj.get("Code"),
        "message": obj.get("Message"),
        "data": obj.get("Data"),
        "request_left": obj.get("RequestLeft"),
        "raw": obj,
    }


def products_of(result) -> list:
    """从 CategoryRequest / ProductSearch 的返回里取出产品列表（结构可能是 list 或 dict）。"""
    d = result.get("data") if isinstance(result, dict) else result
    if isinstance(d, list):
        return d
    if isinstance(d, dict):
        for v in d.values():
            if isinstance(v, list) and v and isinstance(v[0], dict):
                return v
    return []


def series_of(result) -> list:
    """把趋势返回的 [月份, 值, 月份, 值...] 变成 [(月份, 值)]，丢弃非数值点。"""
    s = result.get("data") if isinstance(result, dict) else result
    if not isinstance(s, list):
        return []
    out = []
    for i in range(0, len(s) - 1, 2):
        if isinstance(s[i + 1], (int, float)):
            out.append((s[i], s[i + 1]))
    return out


# ---------------------------------------------------------------- 趋势口径
def month_of(ts):
    return str(ts)[:6]


def is_partial_month(ts, today=None):
    """判断这个月份是不是「不完整当月」。"""
    today = today or date.today()
    return month_of(ts) == today.strftime("%Y%m")


def guard_series(series, today=None):
    """检查趋势序列本身是否可疑，返回 warning 列表。"""
    warn = []
    if len(series) < 3:
        warn.append(f"数据点过少（{len(series)} 个），不足以判断趋势")
        return warn

    months = [month_of(p[0]) for p in series]
    if months != sorted(months):
        warn.append("时间顺序不是递增，疑似数据错位")
    if len(set(months)) != len(months):
        warn.append("存在重复月份")

    if is_partial_month(series[-1][0], today):
        ratio = series[-1][1] / series[-2][1] if series[-2][1] else 0
        warn.append(
            f"末月 {series[-1][0]} 是**不完整当月**（值为前一月的 {ratio*100:.0f}%），"
            "已从趋势计算中剔除；直接做首末对比会得出错误的暴跌结论"
        )

    neg = [p for p in series if p[1] < 0]
    if neg:
        warn.append(f"存在负值 {len(neg)} 个（可能表示缺失/不可估算），已按缺失处理")

    vals = [p[1] for p in series if p[1] >= 0]
    if vals and max(vals) > 0:
        jumps = [(series[i][0], series[i][1] / series[i - 1][1])
                 for i in range(1, len(series))
                 if series[i - 1][1] > 0 and series[i][1] / series[i - 1][1] > 3]
        for ts, k in jumps:
            if not is_partial_month(ts, today):
                warn.append(f"{ts} 出现 {k:.1f} 倍跳变，建议交叉验证")
    return warn


def safe_trend(series, today=None):
    """正确口径的趋势：剔除不完整当月 → 同比 + 中期趋势 + 峰谷比。"""
    today = today or date.today()
    warnings = guard_series(series, today)
    clean = [p for p in series if p[1] >= 0]           # 负值当缺失
    if len(clean) < 3:
        return {"ok": False, "warnings": warnings, "reason": "有效数据点不足"}

    naive = None
    if clean[0][1]:
        naive = (clean[-1][1] - clean[0][1]) / clean[0][1] * 100

    full = [p for p in clean if not is_partial_month(p[0], today)]
    if len(full) < 3:
        return {"ok": False, "warnings": warnings, "reason": "剔除不完整月后数据点不足"}

    last = full[-1]
    base = [p for p in full if month_of(p[0])[4:] == month_of(last[0])[4:] and p[0] != last[0]]
    yoy = None
    if base and base[-1][1]:
        yoy = (last[1] - base[-1][1]) / base[-1][1] * 100

    recent = [p[1] for p in full[-12:]]
    prev = [p[1] for p in full[-24:-12]]
    mid = None
    if prev and sum(prev):
        mid = (sum(recent) / len(recent) - sum(prev) / len(prev)) / (sum(prev) / len(prev)) * 100

    peak = max(full, key=lambda p: p[1])
    trough = min(full, key=lambda p: p[1])
    ratio = peak[1] / trough[1] if trough[1] else None

    return {
        "ok": True,
        "points": len(clean),
        "excluded_partial": [p[0] for p in clean if is_partial_month(p[0], today)],
        "naive_first_vs_last_pct": naive,
        "yoy_pct": yoy, "yoy_base_month": base[-1][0] if base else None,
        "last_full_month": last[0], "last_full_value": last[1],
        "mid_term_pct": mid,
        "peak": peak, "trough": trough, "peak_trough_ratio": ratio,
        "warnings": warnings,
    }


def lifecycle(trend):
    """把趋势翻译成生命周期判断（技能包 market-analysis-framework 第六节口径）。"""
    if not trend.get("ok"):
        return "数据不足，无法判断"
    y, m = trend.get("yoy_pct"), trend.get("mid_term_pct")
    parts = []
    if y is not None:
        parts.append("同比增长" if y > 5 else "同比萎缩" if y < -5 else "同比持平")
    if m is not None:
        parts.append("中期上行" if m > 5 else "中期下行" if m < -5 else "中期平稳")
    if trend.get("peak_trough_ratio") and trend["peak_trough_ratio"] > 3:
        parts.append(f"强季节性（峰谷比 {trend['peak_trough_ratio']:.1f}x）")
    return "，".join(parts)


# ---------------------------------------------------------------- 类目统计
def category_stats(items, today=None):
    """把 Top100 原始记录算成一组可判断的指标（全部经过口径处理）。"""
    if not items:
        raise DataError("没有产品数据，无法统计")
    rows = [norm_product(i) for i in items]

    def col(k):
        return [r[k] for r in rows if r.get(k) is not None]

    price, sales = col("SalesPrice"), col("ListingSalesVolumeOfMonth")
    reviews, rates = col("RatingsCount"), col("ProfitRate")
    fba = col("FbaFee")

    # 品牌：空品牌单独统计，不能混进集中度里
    brand_rows = [r for r in rows if r.get("Brand")]
    unbranded = len(rows) - len(brand_rows)
    from collections import Counter
    bc = Counter(r["Brand"] for r in brand_rows)

    def med(x):
        return sorted(x)[len(x) // 2] if x else None

    total_sales = sum(sales) if sales else 0
    top10 = sum(n for _, n in bc.most_common(10))
    top3 = sum(n for _, n in bc.most_common(3))

    return {
        "产品数": len(rows),
        "月销合计": total_sales,
        "单品月销中位": med(sales),
        "售价中位": med(price),
        "FBA费中位": med(fba),
        "毛利率中位": med(rates),
        "评论中位": med(reviews),
        "评论超1000占比%": round(sum(1 for r in reviews if r > 1000) / len(reviews) * 100, 1)
                           if reviews else None,
        "品牌数": len(bc),
        "无品牌条目数": unbranded,
        "Top3份额%": round(top3 / len(rows) * 100, 1),
        "Top10份额%": round(top10 / len(rows) * 100, 1),
        "FBA占比%": round(sum(1 for r in rows if r.get("IsFBA")) / len(rows) * 100, 1),
        "亚马逊自营数": sum(1 for r in rows
                            if str(r.get("BuyboxSeller") or "").lower().startswith("amazon")),
        "数据缺失提示": (f"{unbranded} 条无品牌字段，集中度仅按有品牌的 {len(brand_rows)} 条计算"
                         if unbranded else None),
    }
