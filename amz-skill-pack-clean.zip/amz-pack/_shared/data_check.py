#!/usr/bin/env python3
"""口径守门层的回归自检 —— 拿真实数据验证「防错规则」是否生效。

用法：python3 scripts/data_check.py
退出码：0 全部通过 / 1 有失败项

这是给「口径」这件事本身做的测试：
一旦有人改坏了 amzdata.py 的换算规则，这里会立刻报出来。
"""

import sys
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
import amzdata  # noqa: E402

RESULTS = []
NODE = "239221011"      # Babycare / Grooming & Healthcare Kits（已验证可用）


def check(name, fn):
    try:
        ok, detail = fn()
    except Exception as e:  # noqa: BLE001
        ok, detail = False, f"{type(e).__name__}: {e}"
    RESULTS.append((name, ok, detail))
    print(f"{'✅' if ok else '❌'} {name}")
    if detail:
        print(f"     {detail}")


def t_money():
    cases = [("12609 → 126.09", amzdata.money(12609), 126.09),
             ("-1 → None（缺失，不是 0）", amzdata.money(-1), None),
             ("None → None", amzdata.money(None), None),
             ("0 → 0.0（真实零价）", amzdata.money(0), 0.0)]
    bad = [c for c, got, want in cases if got != want]
    return (not bad), (f"检查 {len(cases)} 项" if not bad else f"不符合：{bad}")


def t_count():
    cases = [("-1 → None", amzdata.count(-1), None),
             ("3101 → 3101", amzdata.count(3101), 3101)]
    bad = [c for c, got, want in cases if got != want]
    return (not bad), ("缺失值不会被当成 0" if not bad else f"不符合：{bad}")


def t_partial_month():
    today = date(2026, 9, 16)
    ok = amzdata.is_partial_month(202609, today) and not amzdata.is_partial_month(202608, today)
    return ok, "能识别出不完整当月"


def t_live_trend():
    res = amzdata.call("CategoryTrend", {"nodeId": NODE, "trendIndex": 0})
    if res["code"] != 0:
        return False, f"CategoryTrend Code={res['code']}"
    tr = amzdata.safe_trend(amzdata.series_of(res))
    if not tr.get("ok"):
        return False, tr.get("reason")
    gap = abs(tr["naive_first_vs_last_pct"] - (tr["yoy_pct"] or 0))
    return (bool(tr["excluded_partial"]) and gap > 10), (
        f"剔除不完整月 {tr['excluded_partial']}；错误读法 "
        f"{tr['naive_first_vs_last_pct']:+.1f}% vs 正确读法 {tr['yoy_pct']:+.1f}%"
        f"（差 {gap:.0f} 个百分点）")


def t_live_stats():
    res = amzdata.call("CategoryRequest", {"nodeId": NODE})
    items = amzdata.products_of(res)
    if not items:
        return False, f"无产品数据（Code={res['code']}）"
    st = amzdata.category_stats(items)
    ok = bool(st["售价中位"]) and st["售价中位"] < 1000 and st["月销合计"] > 0
    extra = f"；{st['数据缺失提示']}" if st["数据缺失提示"] else ""
    return ok, (f"{st['产品数']} 条 → 售价中位 ${st['售价中位']}、月销 "
                f"{st['月销合计']:,.0f}、Top10 份额 {st['Top10份额%']}%{extra}")


def t_wrong_domain():
    try:
        amzdata.call("ShopRequest", {"shopId": "1"}, domain=1)   # Shopee 端点用 Amazon domain
        return False, "本该报错却成功了"
    except amzdata.DataError as e:
        return ("404" in str(e) or "domain" in str(e)), f"正确拦下：{str(e)[:60]}"


def t_no_data_is_not_error():
    res = amzdata.call("CategoryRequest", {"nodeId": "10922"})   # 图书类目，预期无数据
    return res["code"] == 11, f"Code={res['code']}（11=无数据，按空结果处理，不当故障）"


# ---------- 3. 本轮新增口径（v2）----------
def t_size_parsing():
    got = amzdata.size_cm(["44.30,36.14,12.7"])
    return got == [44.3, 36.14, 12.7], f"['44.30,36.14,12.7'] → {got}（单元素逗号串，不是三元数组）"


def t_fba_detail():
    item = {"FbaFee": 1409, "FbaDetetail": [1369, "1-9:40", "10-12:101"]}
    parts = amzdata.fba_parts(item["FbaDetetail"])
    total = amzdata.fba_total(item)
    ok = parts["配送费"] == 13.69 and total == 14.09
    return ok, f"FbaDetetail[0]={parts['配送费']} 只是配送费；FBA 总额用 FbaFee={total}"


def t_bsr_parsing():
    b = amzdata.bsr_categories({"BsrCategory": [["Robotic Vacuums", "3743561", "125", "20260916"]]})
    ok = b and b[0]["排名"] == 125.0 and b[0]["类目"] == "Robotic Vacuums"
    return bool(ok), f"嵌套数组 → {b}"


def t_sales_volume_string():
    v = amzdata.num_str("2000")
    return v == 2000.0 and "20002000" not in str(v), f"'2000' → {v}（字符串数值必须先转数字）"


def t_history_window():
    start, end = amzdata.history_window(span_days=10)
    res = amzdata.call("CategoryRequest", {"nodeId": NODE, "queryStart": start, "queryDate": end})
    n = len(amzdata.products_of(res))
    return res["code"] == 0 and n > 0, f"合法窗口 {start}~{end} → Code={res['code']}，{n} 条"


def t_history_wrong_param():
    start, end = amzdata.history_window(span_days=10)
    res = amzdata.call("CategoryRequest", {"nodeId": NODE, "queryStart": start, "queryEnd": end})
    return res["code"] == 10, f"写成 queryEnd → Code={res['code']}（正确参数名是 queryDate）"


def t_batch_limit():
    res = amzdata.call("ProductRequest", {"asin": ",".join(["B0CVM8TXHP"] * 11)})
    return res["code"] == 15, f"传 11 个 ASIN → Code={res['code']}（{str(res['message'])[:40]}）"


# ---------- 4. 存疑项验证后固化的规则（v3）----------
def t_range_useless_paging_works():
    """range 参数无效，必须靠翻页——这是选品样本量的关键。"""
    a = amzdata.call("CategoryProducts", {"nodeId": NODE, "page": 1, "range": 100})
    b = amzdata.call("CategoryProducts", {"nodeId": NODE, "page": 1, "range": 2000})
    p2 = amzdata.call("CategoryProducts", {"nodeId": NODE, "page": 2, "range": 2000})
    ia = {i.get("Asin") for i in amzdata.products_of(a)}
    ib = {i.get("Asin") for i in amzdata.products_of(b)}
    i2 = {i.get("Asin") for i in amzdata.products_of(p2)}
    ok = len(ia) == 100 and ia == ib and len(ia & i2) == 0
    return ok, (f"range=100 与 range=2000 结果相同（{len(ia)} 条），"
                f"而 page=1 与 page=2 无重叠 → range 无效、必须翻页")


def t_multi_page_fetch():
    items = amzdata.all_category_products(NODE, pages=3)
    return len(items) > 100, f"翻 3 页去重后拿到 {len(items)} 条（单页只有 100）"


def t_season_format():
    r = amzdata.call("ProductSearch", {"nodeId": "14087331",
                                       "peakSellingSeason": amzdata.season_param([4, 5])})
    n = len(amzdata.products_of(r))
    return r["code"] == 0 and n > 0, (
        f"季节性类目上用 '4,5' → Code={r['code']}，{n} 条"
        f"（注意：非季节性类目返回 Code=11 属正常，不代表参数错）")


def t_keyword_rates():
    r = amzdata.call("KeywordQuery", {"pattern": {"keyword": "power bank"},
                                      "pageIndex": 1, "pageSize": 20})
    ks = r["data"] if isinstance(r["data"], list) else []
    if not ks:
        return False, f"无数据 Code={r['code']}"
    k = ks[0]
    vals = [k.get(f) for f in amzdata.RATE_FIELDS if isinstance(k.get(f), (int, float))]
    cpc = amzdata.cpc_range(k.get("CpcRange"))
    ok = bool(vals) and any(v > 1 for v in vals) and cpc and 0 < cpc[0] < 20
    return ok, (f"率字段是百分数（样本最大 {max(vals):.2f}）；"
                f"CpcRange={k.get('CpcRange')} → ${cpc[0]}–${cpc[1]}" if cpc else "CpcRange 解析失败")


def t_period_expr():
    expr = amzdata.period_expr([1, 2, 3, 4, 5], [2, 3], 1)
    return expr == "1,2,3,4,5|2,3|1", f"构造 period = {expr}（服务端解析成 Day/Time/Frequency）"


# ---------- 5. 监控实跑一轮后固化的格式（v4）----------
def t_parse_batch_list():
    raw = ["202609161800:5a5067e878dc4a889d8ebcdbf79e6a9b:1:202609161813"]
    b = amzdata.parse_batch_list(raw)
    ok = (b and b[0]["批次ID"] == "5a5067e878dc4a889d8ebcdbf79e6a9b"
          and b[0]["完成时间"] == "202609161813")
    return bool(ok), f"冒号串 → {b}"


def t_parse_position():
    p = amzdata.parse_position("第1页，第1/9位")
    return p == {"页": 1, "序号": 1, "总数": 9}, f"'第1页，第1/9位' → {p}"


def t_batch_rows():
    rows = [["B0CPHRPZQL", "http://img", "标题", 1, "", "第1页，第1/9位", "", "",
             4.3, 2764, 3799, 0, "Intoval", "A2BF"]]
    r = amzdata.batch_rows(rows)
    ok = r and r[0]["ASIN"] == "B0CPHRPZQL" and r[0]["价格"] == 37.99 and r[0]["位置"]["页"] == 1
    return bool(ok), f"二维数组 → ASIN={r[0]['ASIN']}, 价格=${r[0]['价格']}, 位置={r[0]['位置']}"


def t_parse_coin_stream():
    data = {"CoinStream": [12, "202609161800", -10, 29985, 28, "202609161540", -5, 29995]}
    rows = amzdata.parse_coin_stream(data)
    ok = len(rows) == 2 and rows[0]["变动"] == -10 and rows[0]["余额"] == 29985
    return ok, f"扁平数组 → {len(rows)} 条记录，最新一条 {rows[0] if rows else '-'}"


def t_bestseller_fields():
    """榜单数据字段偏轻——不能直接算利润。"""
    expected_missing = {"SalesPrice", "FbaFee", "Profit"}
    sample = {"Title": "x", "Price": 2891, "Asin": "B0X", "Brand": "b",
              "ListingSalesVolumeOfMonth": 2168, "Ratings": 4.1}
    missing = expected_missing - set(sample)
    return len(missing) == 3, f"榜单字段不含 {sorted(missing)}，利润需另拉 ProductRequest"


def main():
    print("口径守门层自检（amzdata）")
    print("=" * 62)
    check("金额换算：最小单位 → 美元", t_money)
    check("缺失值：-1 不是 0", t_count)
    check("不完整当月识别", t_partial_month)
    print("-" * 62)
    check("真实趋势：自动剔除不完整月", t_live_trend)
    check("真实类目统计：口径转换", t_live_stats)
    check("domain 传错能被拦下", t_wrong_domain)
    check("Code=11 无数据不当故障", t_no_data_is_not_error)
    print("-" * 62)
    check("Size 嵌套字符串解析", t_size_parsing)
    check("FbaDetetail 只是配送费", t_fba_detail)
    check("BsrCategory 嵌套解析", t_bsr_parsing)
    check("AsinSalesVolume 字符串数值", t_sales_volume_string)
    check("历史回溯：合法窗口可用", t_history_window)
    check("历史回溯：queryEnd 会失败", t_history_wrong_param)
    check("批量超限返回 Code=15", t_batch_limit)
    print("-" * 62)
    check("range 无效 → 必须翻页", t_range_useless_paging_works)
    check("翻页工具能拿到 >100 条", t_multi_page_fetch)
    check("季节性参数格式正确", t_season_format)
    check("关键词派生率字段口径", t_keyword_rates)
    check("监控 period 表达式构造", t_period_expr)
    print("-" * 62)
    check("批次列表是冒号分隔字符串", t_parse_batch_list)
    check("排名位置是中文文本", t_parse_position)
    check("批次详情是二维数组", t_batch_rows)
    check("金币流水是扁平数组", t_parse_coin_stream)
    check("榜单字段偏轻（无利润字段）", t_bestseller_fields)
    print("=" * 62)
    passed = sum(1 for _, ok, _ in RESULTS if ok)
    print(f"通过 {passed}/{len(RESULTS)}")
    sys.exit(0 if passed == len(RESULTS) else 1)


if __name__ == "__main__":
    main()
