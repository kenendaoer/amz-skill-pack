# scripts/cli_call.ps1 — Sorftime CLI 调用封装（Windows / PowerShell 版）
#
# 与 cli_call.sh 等价，给 Windows 用户用（Windows 上没有 bash 也能跑）。
#
# 用法：
#   .\scripts\cli_call.ps1 -Endpoint ProductRequest -Params '{"asin":"B0CVM8TXHP"}' -Domain 1
#
# 退出码：0 成功 / 2 业务错误 / 3 输入或端点错误 / 4 网络或 CLI 异常

param(
  [Parameter(Mandatory=$true)][string]$Endpoint,
  [string]$Params = '{}',
  [int]$Domain = 1,
  [string]$Profile = "",
  [switch]$Raw
)

$ErrorActionPreference = "Stop"

# ---------- 开通/充值链接：环境变量 > 个人配置 > 随包配置 ----------
$signup = $env:SORFTIME_SIGNUP_URL
if (-not $signup) {
  foreach ($f in @("$HOME\.sorftime\signup.env", "$HOME\.config\sorftime\signup.env",
                   (Join-Path $PSScriptRoot "signup.env"))) {
    if (Test-Path $f) {
      $line = Select-String -Path $f -Pattern '^SORFTIME_SIGNUP_URL=' -List
      if ($line) {
        $signup = ($line.Line -split '=', 2)[1].Trim().Trim('"').Trim("'")
      }
      break
    }
  }
}
if ($signup -match '^(?i)(off|none|no|-)$') { $signup = "" }
$hint = if ($signup) { "请从这里开通或充值：$signup" } else { "请先开通账号或充值后重试。" }

if ($Endpoint -notmatch '^[A-Z][A-Za-z0-9]+$') {
  Write-Error "[cli_call.ps1] Endpoint '$Endpoint' 不是 PascalCase 写法，请核对 references/"
  exit 3
}

if (-not (Get-Command sorftime -ErrorAction SilentlyContinue)) {
  Write-Host "[cli_call.ps1] 【未装配】本机没有 sorftime CLI。" -ForegroundColor Yellow
  Write-Host "[cli_call.ps1] 装配：npm install -g sorftime-cli; sorftime add default <Account-SK>"
  Write-Host "[cli_call.ps1] $hint"
  exit 4
}

$args = @("api", $Endpoint, $Params, "--domain", "$Domain")
if ($Profile) { $args += @("--profile", $Profile) }

$out = & sorftime @args 2>&1 | Out-String
$rc = $LASTEXITCODE

if ($rc -ne 0) {
  if ($out -match "status code 404") {
    Write-Host "[cli_call.ps1] 端点不存在：$Endpoint（HTTP 404，未消耗额度）。核对拼写与平台归属。" -ForegroundColor Yellow
    Write-Host "[cli_call.ps1] 提示：--Domain 传错也会 401/404（Amazon 1-14 / Walmart 21 / 1688 601 / Shopee 201+）。"
    exit 3
  }
  Write-Host "[cli_call.ps1] $out" -ForegroundColor Red
  Write-Host "[cli_call.ps1] $hint"
  exit 4
}

if ($Raw) { Write-Output $out; exit 0 }

# 截取 JSON 主体（去掉进度行/ANSI）
$clean = ($out -split "`n" | Where-Object { $_ -match '^\s*[\{\[]' } | Select-Object -First 1)
if ($clean) {
  $idx = $out.IndexOf($clean)
  $clean = $out.Substring($idx)
} else { $clean = $out }

$code = $null
if ($clean -match '"Code"\s*:\s*(-?\d+)') { $code = [int]$Matches[1] }
$msg = ""
if ($clean -match '"Message"\s*:\s*"([^"]*)"') { $msg = $Matches[1] }

Write-Output $clean

if ($code -ne $null -and $code -ne 0) {
  switch ($code) {
    11  { Write-Host "[cli_call.ps1] $Endpoint`: 无数据（Code=11），非错误。" -ForegroundColor Yellow }
    99  { Write-Host "[cli_call.ps1] $Endpoint`: 异步任务已受理（Code=99），稍后查询结果。" -ForegroundColor Yellow }
    694 { Write-Host "[cli_call.ps1] $Endpoint`: 额度不足（Code=694）。$hint" -ForegroundColor Yellow }
    401 { Write-Host "[cli_call.ps1] $Endpoint`: 该 API 不可用（Code=401），优先检查 -Domain。" -ForegroundColor Yellow }
    default {
      Write-Host "[cli_call.ps1] $Endpoint business error code=$code message=$msg" -ForegroundColor Red
      if ($msg -match 'nsufficient|quota|余额|不足') { Write-Host "[cli_call.ps1] $hint" }
    }
  }
  exit 2
}
exit 0
