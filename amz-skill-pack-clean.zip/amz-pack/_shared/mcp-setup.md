# Sorftime MCP 配置指南（跨 agent 通用）

> 目标：让任何 agent 都能连上 Sorftime MCP。四条通道任选其一即可。
> Sorftime MCP 是 **streamable HTTP** 服务，地址形如 `https://mcp.sorftime.com?key=<Account-SK>`。
> Account-SK 获取：登录 [seller.sorftime.com/mcp](https://seller.sorftime.com/mcp) 复制（API 与 CLI 共用同一个 Key）。

---

## 一、Codex（CLI / 桌面版）

```bash
codex mcp add sorftime --url "https://mcp.sorftime.com?key=<你的Account-SK>"
codex mcp list          # 确认状态 enabled
```

或直接编辑 `~/.codex/config.toml`：

```toml
[mcp_servers.sorftime]
url = "https://mcp.sorftime.com?key=<你的Account-SK>"
```

改完 **新开一个任务** 生效（MCP 在会话启动时加载）。

---

## 二、Claude Code（原生支持 HTTP）

```bash
claude mcp add --transport http sorftime "https://mcp.sorftime.com?key=<你的Account-SK>"
# 想让所有项目都能用：加 --scope user
```

或编辑 `~/.claude.json` / `~/.claude/mcp.json`：

```json
{
  "mcpServers": {
    "sorftime": {
      "type": "http",
      "url": "https://mcp.sorftime.com?key=<你的Account-SK>"
    }
  }
}
```

---

## 三、Claude Desktop（只支持 stdio，需要桥接）

编辑 `~/Library/Application Support/Claude/claude_desktop_config.json`（Windows：`%APPDATA%\Claude\claude_desktop_config.json`）：

```json
{
  "mcpServers": {
    "sorftime": {
      "command": "npx",
      "args": ["-y", "mcp-remote", "https://mcp.sorftime.com?key=<你的Account-SK>"]
    }
  }
}
```

保存后**完全退出并重启** Claude Desktop。需要 Node.js 18+。

---

## 四、其它 agent / 通用 MCP 客户端

大多数支持 streamable HTTP 的客户端都接受同一份配置：

```json
{
  "mcpServers": {
    "sorftime": {
      "type": "http",
      "url": "https://mcp.sorftime.com?key=<你的Account-SK>"
    }
  }
}
```

常见落点：项目根目录 `.mcp.json`、`~/.agents/mcp.json`、`~/.workbuddy/mcp.json`、`~/.config/mcp/`、`.cursor/mcp.json`、`.vscode/mcp.json`。
只支持 stdio 的客户端，统一用 `npx -y mcp-remote <url>` 桥接（同第三节）。

**WorkBuddy**：把上面这段 JSON 写进 `~/.workbuddy/mcp.json`（外层同样是 `mcpServers`），
然后在客户端的连接器页面点一次「信任」启用；`scripts/channel_check.py` 会自动识别这个落点。

---

## 五、验证 MCP 是否通

```bash
curl -sS -X POST "https://mcp.sorftime.com?key=<你的Account-SK>" \
  -H "Content-Type: application/json" \
  -H "Accept: application/json, text/event-stream" \
  -d '{"jsonrpc":"2.0","id":1,"method":"initialize","params":{"protocolVersion":"2025-06-18","capabilities":{},"clientInfo":{"name":"probe","version":"1.0"}}}'
```

返回 `serverInfo.name = Sorftime MCP` 即正常。**此调用不消耗额度。**

在 agent 内更简单的验证：让 agent 调用 `get_time`（0 消耗）。

---

## 六、没有 MCP 也能跑

只配 CLI 通道同样可以跑通全部 10 个技能（批量类任务反而更适合 CLI）：

```bash
npm install -g sorftime-cli
sorftime add default <你的Account-SK>
sorftime use default
sorftime api CoinQuery        # 验证：返回剩余额度即成功，0 消耗
```

两个通道可同时存在，`scripts/channel_check.py` 会自动选择。
