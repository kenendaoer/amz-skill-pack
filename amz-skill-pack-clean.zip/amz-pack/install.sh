#!/usr/bin/env bash
# install.sh — 把 amz-* 技能包安装进任意 agent 的技能目录
#
# 设计目标：**同一份包，装到任何 agent 上都能跑**。
#   - 不依赖固定用户名 / 固定绝对路径
#   - 每个技能装完都是自包含的（自带 shared/ 共享层）
#   - 已存在的同名技能会被替换（只替换 amz-*，不动你其它技能）
#
# 用法：
#   ./install.sh                          # 自动探测常见 agent 目录并安装
#   ./install.sh --target ~/.codex/skills # 只装到指定目录（可重复多次）
#   ./install.sh --dry-run                # 只显示会做什么，不实际写入
#
set -uo pipefail

SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DRY_RUN=0
TARGETS=()

usage() {
  sed -n '2,20p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
  cat <<'EOF'

常见技能目录：
  ~/.agents/skills    通用共享库（Codex / Claude Code / OpenClaw 等都认这个约定）
  ~/.workbuddy/skills  WorkBuddy
  ~/.codex/skills     Codex
  ~/.claude/skills    Claude Code
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    -h|--help) usage; exit 0 ;;
    --target)  TARGETS+=("${2:-}"); shift 2 ;;
    --dry-run) DRY_RUN=1; shift ;;
    *) echo "[install.sh] 未知参数：$1" >&2; usage >&2; exit 3 ;;
  esac
done

# ---------- 1. 确定目标目录 ----------
if [ ${#TARGETS[@]} -eq 0 ]; then
  [ -d "$HOME/.agents" ] || mkdir -p "$HOME/.agents/skills"
  TARGETS+=("$HOME/.agents/skills")
  [ -d "$HOME/.workbuddy" ] && TARGETS+=("$HOME/.workbuddy/skills")
  [ -d "$HOME/.codex" ]  && TARGETS+=("$HOME/.codex/skills")
  [ -d "$HOME/.claude" ] && TARGETS+=("$HOME/.claude/skills")
fi

# ---------- 2. 收集技能 ----------
SKILLS=()
for d in "$SRC"/amz-*/; do
  [ -d "$d" ] && SKILLS+=("$(basename "$d")")
done

if [ ${#SKILLS[@]} -eq 0 ]; then
  echo "[install.sh] 没找到 amz-* 技能目录，确认你在包的根目录运行" >&2
  exit 3
fi

echo "源目录：$SRC"
echo "技能数：${#SKILLS[@]}（${SKILLS[*]}）"
echo "目标：${TARGETS[*]}"
[ "$DRY_RUN" -eq 1 ] && echo "（dry-run：只演示，不写入）"
echo

# ---------- 3. 安装 ----------
installed=0
for TARGET in "${TARGETS[@]}"; do
  case "$TARGET" in
    "~"*) TARGET="${HOME}${TARGET#\~}" ;;   # 支持写 ~/xxx
  esac
  echo "==> $TARGET"
  [ "$DRY_RUN" -eq 0 ] && mkdir -p "$TARGET"

  for name in "${SKILLS[@]}"; do
    dest="$TARGET/$name"
    if [ "$DRY_RUN" -eq 1 ]; then
      echo "    [dry-run] 安装 ${name}（含 scripts/ 与 shared/）"
      continue
    fi
    rm -rf "$dest"
    cp -R "$SRC/$name" "$dest"
    chmod +x "$dest/scripts/"* 2>/dev/null
    # 自包含性校验：缺文件说明包不完整
    for need in scripts/channel_check.py scripts/cli_call.sh shared/CHANNEL.md shared/report-format.md; do
      [ -e "$dest/$need" ] || echo "    ⚠️  ${name} 缺少 ${need}（包可能不完整）"
    done
    echo "    安装 $name （含 shared/）"
    installed=$((installed + 1))
  done

  # 全链路地图放在技能根目录，便于作为普通文档阅读
  if [ "$DRY_RUN" -eq 0 ]; then
    cp "$SRC/amz-workflow-map.md" "$TARGET/amz-workflow-map.md"
  fi
done

if [ "$DRY_RUN" -eq 1 ]; then
  echo
  echo "dry-run 结束。去掉 --dry-run 即真正安装。"
  exit 0
fi

echo
echo "✅ 完成：共安装 $installed 个技能副本"
cat <<'EOF'

下一步（二选一，或都配）：

  ① MCP 通道（推荐，对话内直接跑）
     见 <技能目录>/amz-selection/shared/mcp-setup.md

  ② CLI 通道（批量/监控必备）
     npm install -g sorftime-cli
     sorftime add default <你的Account-SK>
     sorftime use default

自检：
  python3 <技能目录>/amz-selection/scripts/doctor.py

注意：新装的技能通常要**新开一个会话**才会被 agent 加载。
EOF
