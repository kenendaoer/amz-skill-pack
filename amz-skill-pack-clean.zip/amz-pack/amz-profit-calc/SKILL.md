---
name: amz-profit-calc
description: Sorftime 亚马逊利润测算 / 隐赚分析。当用户要算利润、算 FBA 费用、算盈亏平衡点、做定价策略、判断隐赚指数/HPI、找轻量小而美高利润品、测算单均毛利净利、评估某 ASIN 能不能赚钱，或说"利润测算/利润计算/FBA费用/佣金/盈亏平衡/保本销量/隐赚/隐赚指数/HPI/轻量利润/小而美/定价/毛利/净利/利润表/profit calculation/FBA fee/break-even/invisible profit/HPI/lightweight profit/pricing strategy/margin"时使用。融合隐赚指数、轻量利润、定价位置方法论，用 ProductRequest 取真实价格/排名/费用数据，输出利润测算表（成本/费用/毛利/净利/盈亏平衡销量/隐赚评分）。默认 Amazon US，支持多站点。
---

# amz-profit-calc — 利润测算 / 隐赚

给一个 ASIN（或一组假设成本/售价）算出真实利润账：FBA 费用、平台佣金、广告、退货侵蚀、盈亏平衡销量、隐赚评分。

> 链路位置：第 4 环「利润测算」。上游 ← amz-supply-chain（采购成本）；下游 → amz-cpc-keywords（go 后建词库）。全链路地图见 `shared/amz-workflow-map.md`。

## 前置检查

开始前先运行：

```bash
python3 scripts/channel_check.py
```
> 🚨 **凭证缺失 / 额度用尽时的标准动作（必须执行）**
> - **未装配**：通道检测返回 `setup_required: true`（MCP 与 CLI 都不可用）时，不要凭空执行数据调用；明确告知用户「当前 agent 还没有装配 Sorftime 通道」，然后**原样输出** `channel_check.py` 返回的 `signup_url`。
> - **额度用尽**：通道可用但调用返回额度不足（`Code=694` / `Code=401` / `quota` / 余额不足 / Insufficient）时，**立刻停止后续调用**，告知用户额度已用尽，并原样输出同一个 `signup_url`。
> - 若 `signup_url` 为空或 `promo_enabled: false`：只说明「需要先开通 / 充值」，**不要输出任何链接**。
> - 有链接时必须给出**完整可点击**的链接，不要只说「请去官网开通」。
> 📘 通道能力边界 / domain 对照 / 错误码 / 已知限制见 [shared/CHANNEL.md](shared/CHANNEL.md)；MCP 工具 ↔ CLI 端点对照见 [shared/mcp-map.md](shared/mcp-map.md)；MCP 怎么配置见 [shared/mcp-setup.md](shared/mcp-setup.md)。
> 📐 **所有派生指标必须走口径守门层**：金额是最小单位（÷100）、`-1` 是缺失不是 0、趋势末月不完整——规则见 [shared/DATA-CONTRACT.md](shared/DATA-CONTRACT.md)，代码用 `scripts/amzdata.py` 与 `scripts/trend.py`，自检 `python3 scripts/data_check.py`。


按 `recommended_channel` 选 MCP 或 CLI 通道。默认 site=US（domain=1）。

## 典型流程

1. **取真实数据**（MCP `product_detail` 或 CLI `ProductRequest`）：售价 SalesPrice、FbaFee、PlatformFee、Profit、ProfitRate、Weight、月销 AsinSalesVolume
2. **补假设成本**：采购成本（含头程）问用户，或用 1688 价估算
3. **跑测算**：`scripts/profit_calculator.py`（或在线 P&L）
4. **出利润表 + 隐赚评分 + 盈亏平衡 + go/no-go**

公式见 [references/profit-formula.md](references/profit-formula.md)。

---

## MCP 通道

- `product_detail` — 取 SalesPrice / FbaFee / FbaDetetail / PlatformFee / Profit / ProfitRate / RatingsCount / Weight / Size / OnlineDate
- `product_trend` — 取 6 个月销量/价格趋势（判断盈利可持续性）
- `product_variations` — 变体矩阵（算套装/多件变体利润）

---

## CLI 通道

端点文档见 [references/endpoints-reference.md](references/endpoints-reference.md)。

```bash
# 1. 取单品真实价格/FBA费/佣金/利润（最关键一步）
scripts/cli_call.sh ProductRequest '{"asin": "B0CVM8TXHP"}'

# 2. 取官方披露的变体销量历史（算月销）
scripts/cli_call.sh AsinSalesVolume '{"asin": "B0CVM8TXHP"}'

# 3. 取全部变体（套装/多件 SKU 利润）
scripts/cli_call.sh ProductVariations '{"asin": "B0CVM8TXHP"}'
```

> ⚠️ **实测注意（2026-09-16）**：`AsinSalesVolume` 返回 `Code=0` 但数据为空属**正常情况**——
> 亚马逊只在部分类目（如服装、鞋靴等共享排名类目）官方披露变体销量，其它类目无数据。
> **处理规则**：数据为空时**回退到 `ProductRequest` 的月销字段**（`ListingSalesVolumeOfMonth`），
> 并在报告里标注 `[官方未披露变体销量]`。**不要把空值当 0 参与利润计算。**

拿到 SalesPrice / FbaFee / 月销后，喂给本地测算脚本：

```bash
# 用真实拉到的 FBA 费覆盖估算
python3 scripts/profit_calculator.py \
  --price 24.99 --cost 6.5 --weight 0.35 \
  --fba-fee 4.75 --monthly-sales 800 --return-rate 0.05

# 只看公式样例
python3 scripts/profit_calculator.py --json
```

非 US 站点加 `--domain <N>`。

---

## 输出规范

利润测算表必须包含：

| 项目 | 来源 |
|---|---|
| 售价 / 采购成本 | 用户输入 或 ProductRequest.SalesPrice |
| FBA 配送费 | ProductRequest.FbaFee（优先）/ 估算 |
| 平台佣金(Referral) | ProductRequest.PlatformFee |
| 广告成本(估 ~15%) | 假设，标注 |
| 单均毛利 / 毛利率 | 计算 |
| 退货后单均净利 | 按退货率敏感性 |
| 盈亏平衡销量 | 按月固定成本 |
| 月净利 | 月销 × 单均净利 − 固定成本 |
| 隐赚评分 | 本地代理分（官方 HPI 走 MCP potential_product） |
| go / caution / no-go | 综合净利 + 退货敏感性 |

⚠️ 所有利润数字是**估算**；FBA 费必须以官方 Revenue Calculator 复核（尤其大件/异形）；广告占比、退货率按类目假设，须显式标注 `[ASSUMED]`。
