# 亚马逊卖家全链路工作流地图（amz-* 10 Skill）

> 数据全部来自 Sorftime（MCP / CLI 双通道）。每个 Skill 开头跑 `scripts/channel_check.py` 选通道。
> 本图于 2026-09-10 全链路实测跑通（CLI 通道，domain=1 / 1688=601）。

## 主链：从选品到卖得好

```
① 选品                ② 市场验证             ③ 找货源
amz-selection    →    amz-market-analysis →  amz-supply-chain
候选≥20+go/no-go      11维评分/价格带甜区     1688货源+价差
       │                                            │
       └──────────────┐                ┌────────────┘
                      ▼                ▼
              ④ 利润测算 amz-profit-calc
              毛利/盈亏平衡/隐赚评分 → go?
                      │ go
                      ▼
              ⑤ 关键词词库 amz-cpc-keywords
              4分类×≥200词（核心/长尾/场景/痛点）
                      │
          ┌───────────┼───────────────┐
          ▼           ▼               ▼
  ⑥ Listing      ⑦ 做图           ⑧ 广告
  amz-listing-    amz-image-       amz-ad-planning
  creator         creator          活动结构/预算/否定词
  标题五点描述      主图/A+/场景图
          └───────────┴───────────────┘
                      ▼
                  上架发布
                      │
          ┌───────────┴───────────┐
          ▼                       ▼
  ⑨ VOC 复盘              ⑩ 盯盘监控
  amz-voc-analysis        amz-competitor-monitor
  痛点/卖点/场景           排名/跟卖/榜单告警
          └─────── 反哺 ①⑥⑦⑧ ──────┘
```

## 环间数据交接（handoff）

| 从 → 到 | 交接物 | 关键字段 |
|---|---|---|
| ① → ② | 候选类目 + ASIN 清单 | nodeId、Top 候选 ASIN |
| ② → ③ | 目标产品定义 | 产品名、目标 ASIN、价格带甜区 |
| ③ → ④ | 成本与售价 | 1688 批发价(¥)、Amazon SalesPrice、FbaFee、PlatformFee |
| ④ → ⑤ | go 决策 + 标的 | 目标 ASIN、售价、毛利率 |
| ⑤ → ⑥ | 4 分类词库 | 核心词→Title、长尾/场景→Bullets、其余→Backend |
| ⑤ → ⑧ | 词库（含出价数据） | SearchVolume、CPC 区间、竞争度分 |
| ⑥ → ⑦ | 卖点与关键词 | FABE 卖点清单、高频词（图片文字） |
| ⑨ → ⑥⑦ | VOC 素材 | Top 痛点、好评卖点、使用场景 |
| ⑩ → ⑧⑨ | 告警 | 排名波动、差评激增、跟卖入侵 |

## 单环成本参考（CLI 通道实测）

| 环 | 一次完整跑动消耗 | 说明 |
|---|---|---|
| ① 选品 | ~15-30 请求 | 搜品 2 页 + 详情批量 + 类目校验 |
| ② 市场分析 | ~53 积分 | 官方建议预算（含 6 维趋势） |
| ③ 找货源 | ~5-10 请求 | 1688 搜品 2 + 详情 1 + 变体 1 |
| ④ 利润测算 | 2-3 请求 | ProductRequest + 变体，本地脚本零消耗 |
| ⑤ 词库 | ~50-100 请求 | 拓展 5/页 × 多页 + 反查 + 详情 |
| ⑥ Listing | ~10-20 请求 | 关键词详情 + 竞品反查 |
| ⑦ 做图 | 2-3 请求 + 生图额度 | 数据辅助走 Sorftime，渲染走 gen-image.sh |
| ⑧ 广告规划 | ~10 请求 | 复用 ⑤ 的词库可省 |
| ⑨ VOC | 5-15 Credits | 评论查询 5/页；实时采集另计 |
| ⑩ 监控 | 按任务计 Credits | 关键词监控 504/周/词；跟卖 2/次/ASIN |

## 依赖（全部随包分发，无需外部工作台配置）

| 依赖 | 位置 | 说明 |
| --- | --- | --- |
| 通道检测 | `scripts/channel_check.py`（每个技能各一份） | 自动识别 MCP / CLI |
| 环境自检 | `scripts/doctor.py` | 一键检查通道、凭证、共享文件、真实调用 |
| CLI 封装 | `scripts/cli_call.sh` | 纯 shell 实现，不依赖 jq / python3 |
| 生图封装 | `scripts/gen-image.sh` | 三条兜底路径；未配置时退化为「只出提示词」 |
| 通道规范 | `shared/CHANNEL.md` | 能力边界 / domain 对照 / 错误码 / 已知限制 |
| MCP 配置 | `shared/mcp-setup.md` | Codex / Claude Code / Claude Desktop / 通用客户端 |
| 端点对照 | `shared/mcp-map.md` | MCP 工具 ↔ CLI 端点 |
| 报告规范 | `shared/report-format.md` | HTML + 主图 + 可跳转链接 + 中文 |

## 实测验证记录（v2，2026-09-16，CLI 通道）

本轮把技能包里**每一条写出来的调用示例**拿去真跑（消耗 113 请求 + 5 金币）：

| 环 | 验证调用 | 结果 |
|---|---|---|
| ① | `ProductSearchFromName {"name":"slow feeder bowl","pageIndex":1}` | ✅ 65 字段 / 17.8 万字节 |
| ② | `CategorySearchFromName` / `CategoryRequest` / `CategoryTrend` / `CategoryProducts` / `CategoryRequestKeyword` / `ProductSearch` / `SimilarProductFeature` | ✅ 全部返回数据 |
| ③ | `ProductSearchFromName --domain 601`、`ProductRequest --domain 601` | ✅ 1688 数据正常 |
| ④ | `ProductRequest` / `ProductVariations`（isSalesVolume=true 扣 2 积分，与文档一致） | ✅ 14/14 文档字段全部存在 |
| ⑤ | `KeywordRequest` / `KeywordExtends` / `KeywordSearchResults` / `KeywordQuery` / `ASINRequestKeyword` | ✅ |
| ⑥ | `ASINRequestKeyword`（流量词反查） | ✅ |
| ⑦ | 生图通道改为三条兜底路径，未配置也可交付方案 | ✅ 不再阻塞链路 |
| ⑧ | `KeywordRequest`（CPC/搜索量） | ✅ |
| ⑨ | `ProductReviewsQuery` / `ProductCustomersSay` / `AlexaQuestionsCollection` | ✅（`AlexaQuestionsQuery` 受额度限制，已标注降级路径） |
| ⑩ | `KeywordTasks` / `BestSellerListTask` | ✅ 协议正常；⚠️ `ProductTrend` 已修正为 `ProductRequest(trend=1)`；`BestSellerListDataCollect` 返回无数据，待与官方确认 |

### v1 原始实测记录（2026-09-10）

| 环 | 验证调用 | 结果 |
|---|---|---|
| ① | ProductSearchFromName "slow feeder bowl" | ✅ 返回月销 1.2w+ 候选 |
| ② | CategorySearchFromName "slow feeder" → 17602455011；CategoryRequest | ✅ |
| ③ | ProductSearchFromName --domain 601 | ✅ 批发价 ¥2.39 起 |
| ④ | ProductRequest B0CVM8TXHP + profit_calculator.py | ✅ |
| ⑤ | KeywordRequest / KeywordExtends / CategoryRequestKeyword | ✅ |
| ⑥ | ASINRequestKeyword（流量词反查） | ✅ |
| ⑦ | gen-image.sh generate（白底主图） | ✅ |
| ⑧ | KeywordRequest（CPC/搜索量） | ✅ |
| ⑨ | ProductCustomersSay / ProductReviewsQuery | ✅ |
| ⑩ | KeywordTasks（监控任务查询） | ✅ 协议正常（账户暂无任务） |

## 注意事项

- 只配了 CLI（没配 MCP）是完全正常的运行方式；channel_check.py 会自动落到 CLI，批量与监控任务反而更适合 CLI。
- `potential_product`（HPI 官方端点）仅 MCP 有；CLI 通道用本地隐赚代理分替代（见 amz-profit-calc）。
- 监控类端点消耗 Credits（每月 10 号清零），注册任务前先算周成本。
- 站点参数：Amazon `1`（US）；1688 固定 `601`；Walmart `21`；Shopee `201+`。**传错 domain 会 401/404。**
- 报告输出遵循 `shared/report-format.md`：单文件 HTML + 主图 + 可跳转链接 + 中文。
- 更完整的坑与限制见 `shared/CHANNEL.md`（含错误码表、`ScheduelId` 拼写陷阱、Alexa 额度说明）。
