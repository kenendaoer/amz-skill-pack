# Amazon 卖家全流程 Skill 包（amz-* ×10）· v2 通用版

> **一句话**：把亚马逊卖家从选品到盯盘的 10 个环节做成 10 个技能，数据统一走 Sorftime，
> **装到任何 agent 上都能跑，走 MCP 或走 CLI 都可以。**
>
> 覆盖链路：选品 → 市场分析 → 找货源 → 利润测算 → 关键词词库 → Listing → 做图 → 广告规划 → VOC → 竞品监控

---

## 一、为什么有 v2

v1 能在特定机器上跑，但有几处「换个环境就断」的问题，v2 全部修掉：

| v1 的问题 | v2 的处理 |
| --- | --- |
| 依赖外部绝对路径（`~/.codex/scripts/gen-image.sh`、`~/.codex/rules/report-format.md`） | 改为**包内自带** `shared/`，每个技能装完都自包含 |
| 通道检测只认环境变量，MCP 配好了也检测不到 | 重写 `channel_check.py`，自动识别 Codex / Claude Code / Claude Desktop / 通用 mcp.json |
| `amz-competitor-monitor` 用了亚马逊不存在的 `ProductTrend` 端点 | 改为 `ProductRequest`（`trend=1`），并标注原因 |
| `cli_call.sh` 内部依赖 python3 / jq，缺一个就没法判断业务错误 | 改为纯 shell 解析，无外部依赖 |
| 没有安装脚本，装到别的 agent 要手工拷 | 新增 `install.sh`，自动探测常见 agent 技能目录 |
| 实测会失效的能力没有说明 | 在 `shared/CHANNEL.md` 集中列出「已知限制」与降级路径 |

---

## 二、包内容

| 目录 | 环节 | 一句话说明 |
| --- | --- | --- |
| `amz-selection` | ① 选品 | 6 大选品指数全排序，≥20 候选 + go/no-go |
| `amz-market-analysis` | ② 市场分析 | 11 维复合评分判断「类目值不值得进」 |
| `amz-supply-chain` | ③ 找货源 | 1688 找货/比价/供应商评分（domain=601） |
| `amz-profit-calc` | ④ 利润测算 | 单均 P&L / 盈亏平衡 / 隐赚代理分 |
| `amz-cpc-keywords` | ⑤ 关键词词库 | 4 分类打标（核心/长尾/场景/痛点） |
| `amz-listing-creator` | ⑥ Listing | 两段式标题（75 字符新规）+ 五点 + 后台词 + 8 维评分 |
| `amz-image-creator` | ⑦ 做图 | 数据驱动卖点可视化 + 三条生图兜底路径 |
| `amz-ad-planning` | ⑧ 广告规划 | 活动结构 / 预算 / 出价 / 否定词（纯数据驱动） |
| `amz-voc-analysis` | ⑨ VOC | 差评痛点 / 好评卖点 / Q&A / 场景提取 |
| `amz-competitor-monitor` | ⑩ 竞品监控 | 排名 / 榜单 / 跟卖监控 + 盯盘日报 |
| `amz-workflow-map.md` | 全链路地图 | 流程图 + 环间数据交接 + 单环成本 + 实测记录 |
| `_shared/` | 共享层 | 通道规范、MCP 配置、MCP↔CLI 对照、报告规范、生图封装、自检脚本 |
| `_build/` | 维护脚本 | 改完 `_shared/` 后同步进各技能、检查 shell 中文变量坑 |
| **`shared/DATA-CONTRACT.md`** | **数据口径手册** | **原始数据不能直接用**：7 个高频坑 + 正确处理规则 |
| `scripts/amzdata.py` | 口径守门层 | 金额换算、缺失值、趋势口径、类目统计的统一实现 |
| `scripts/trend.py` | 趋势正确读法 | 自动剔除不完整当月，同时打印错误读法与正确读法 |
| `scripts/data_check.py` | 口径回归自检 | 拿真实数据验证防错规则是否生效 |

---

## 三、安装（3 步）

### 1. 装技能

```bash
./install.sh                          # 自动探测常见 agent 目录
./install.sh --target ~/.codex/skills # 或指定目录（可重复）
./install.sh --dry-run                # 先看看会做什么
```

| Agent | 技能目录 |
| --- | --- |
| 通用共享库（推荐） | `~/.agents/skills` |
| WorkBuddy | `~/.workbuddy/skills` |
| Codex | `~/.codex/skills` |
| Claude Code | `~/.claude/skills` |

装完每个技能都是**自包含**的（不依赖外部工作台配置）：

```
~/.agents/skills/amz-selection/
├── SKILL.md
├── references/         方法论 + 端点文档
├── scripts/            channel_check.py / cli_call.sh / doctor.py / gen-image.sh
└── shared/             CHANNEL.md / mcp-map.md / mcp-setup.md / report-format.md / amz-workflow-map.md
```

### 2. 配数据通道（二选一，也可都配）

**走 MCP**（对话内直接跑）：见 [shared/mcp-setup.md](_shared/mcp-setup.md)，含 Codex / Claude Code / Claude Desktop / 通用客户端的配置写法。

**走 CLI**（批量与监控必备）：

```bash
npm install -g sorftime-cli
sorftime add default <你的Account-SK>
sorftime use default
sorftime api CoinQuery          # 验证：返回剩余额度即成功（0 消耗）
```

Account-SK 获取：登录 <https://seller.sorftime.com/mcp> 复制（API 与 CLI 共用同一个 Key）。

> 还没开通 / 额度用尽 → <https://open.sorftime.com/home?tag=NjE4OA~~>（含 7 天试用，优惠码 **6188**）。
> 链接与优惠码由 `_shared/signup.env` 统一管理（`SORFTIME_SIGNUP_URL` / `SORFTIME_PROMO_CODE`），10 个技能与所有脚本共用同一份，改一处即可全包生效。

### 3. 自检

```bash
python3 ~/.agents/skills/amz-selection/scripts/doctor.py
```

依次检查：通道是否可用 → CLI 凭证与余额 → 共享文件是否齐全 → 一次真实调用是否成功。

---

## 四、怎么用

直接用自然语言下达任务，技能会按 description 自动命中：

- 「帮我看看 artificial flowers 这个类目能不能做」→ ② 市场分析
- 「算一下 B0XXXX 这个品能不能赚钱」→ ④ 利润测算
- 「给这个产品建关键词词库」→ ⑤ 词库
- 「按新规则写一条 listing」→ ⑥ Listing
- 「分析这个竞品最近 30 天的价格和排名变化」→ ⑩ 竞品监控

完整跑单按 `amz-workflow-map.md` 的顺序执行，每环输出即下一环输入。

---

## 五、双通道怎么选

每个技能开头都会先跑 `scripts/channel_check.py`，再按结果分流：

| 场景 | 用哪条 |
| --- | --- |
| 日常查询、分析、解读 | **MCP**（对话闭环，AI 直接解读结果） |
| 批量 100+ ASIN/关键词、定时任务 | **CLI** |
| 注册监控任务（关键词/榜单/跟卖） | **CLI**（MCP 不支持） |
| 隐赚指数 HPI、跨类目筛选、1688 以图搜货 | **MCP**（CLI 无对应端点） |
| AI 生成分析报告、实时强制拉取 | **CLI** |

完整能力边界、domain 对照表、错误码、已知限制：[shared/CHANNEL.md](_shared/CHANNEL.md)。
MCP 工具 ↔ CLI 端点对照：[shared/mcp-map.md](_shared/mcp-map.md)。

### 维护这套包（改完记得同步）

```bash
python3 _build/sync_shared.py          # 把 _shared/ 同步进 10 个技能（保持自包含）
python3 _build/check_shell_unicode.py  # 检查 shell 里 $VAR 紧挨中文的写法（bash 会报错）
./install.sh                           # 重新安装到各 agent 目录
```

---

## 六、使用注意

1. **默认站点 Amazon US（`--domain 1`）**；1688 固定 `601`；Walmart `21`；Shopee `201+`。**传错 domain 会直接 401/404。**
2. **金额字段是最小货币单位**：`1999` = $19.99；CPC 同样以分为单位。
3. **缺失值返回 `-1`**，不是 0，不要当真实值参与计算。
4. **监控类端点消耗 Credits**（每月 10 号清零）。注册前先算周成本（例：1 个关键词 7×24×每小时 1 次×前 3 页 = 504 Credits/周）。
5. **`ScheduelId` 是官方拼写**（Schedule 拼错版），传正确的 `ScheduleId` 反而报错，不要改。
6. **Listing 标题按 2025-07-27 新规**：主标题 ≤75 字符 + 副标题。
7. **报告输出**遵循 [shared/report-format.md](_shared/report-format.md)。
8. **没有生图通道也能跑**：第 ⑦ 环会退化为「输出完整提示词方案」。
9. **派生指标一律走口径守门层**（见 [shared/DATA-CONTRACT.md](_shared/DATA-CONTRACT.md)）：
   金额是最小货币单位、`-1` 是缺失不是 0、**趋势末月是不完整当月**——
   不按规则处理，结论可能反向（实测真实 +0.7% 被算成 −59.1%）。

---

## 七、实测状态（2026-09-16）

| 项 | 状态 |
| --- | --- |
| 技能包 23 条文档示例调用 | ✅ 20 条直接可用；3 条已在本版修正或标注 |
| 端点存在性（64 个） | ✅ 全部核对（10 个「404」实为 domain 传错，已确认） |
| 通道检测 | ✅ CLI 通道通过；MCP 检测逻辑已重写 |
| 主要端点字段名 | ✅ `ProductSearchFromName` 8/8、`CategoryRequest` 14/14、`ProductRequest` 14/14 |
| 已知受限能力 | ⚠️ `AlexaQuestionsQuery`（额度）、`BestSellerListDataCollect`（无数据）——见 `shared/CHANNEL.md` 第六节 |

---

## 八、本包定制说明（2026-09-17）

在 v2 通用版基础上做了三处定制，只动「渠道与落点」，未改任何方法论与端点：

| 项 | 内容 |
| --- | --- |
| 推广链接 | `SORFTIME_SIGNUP_URL` = `https://open.sorftime.com/home?tag=NjE4OA~~` |
| 优惠码 | `SORFTIME_PROMO_CODE` = `6188`（`channel_check.py` / `doctor.py` / `cli_call.sh` 会随链接一起打印；`promo_code` 也进了 JSON 输出） |
| WorkBuddy 支持 | `channel_check.py` 新增落点 `~/.workbuddy/mcp.json` 的识别；`install.sh` 自动探测 `~/.workbuddy/skills` |

链接与优惠码的唯一来源仍是 `_shared/signup.env`——改完跑 `python3 _build/sync_shared.py` 全包同步，不要手改各技能里的副本。

---

## 九、跨 agent / 跨系统兼容性（2026-09-17 核对）

**结论先说**：这套包**不是「任何 agent、任何电脑」都能开箱即用**。发人之前先确认对方的 agent 和系统，见下表。

| 维度 | 状态 | 说明 |
| --- | --- | --- |
| Agent 支持 skills | ✅ | WorkBuddy、Claude Code、Codex、OpenClaw 等有「技能目录」约定的 agent 可直接用 |
| Agent 不支持 skills | ❌ 装不进去 | Claude Desktop、ChatGPT 网页版、Cursor/Windsurf 原生等没有技能机制，只能把包当「文档 + 脚本」手动跑 |
| macOS / Linux | ✅ 已实测 | `./install.sh` + bash 脚本 + `python3`，全套验证通过 |
| Windows | ⚠️ 脚本齐但**未实测** | 原因与绕法见下 |
| 有 Sorftime 凭证 | ⚠️ 硬前提 | 客户没账号/没装配通道 → 10 个技能全都拉不到数据，只会提示开通。**这是发给客户前最该确认的一件事** |

### Windows 客户要提前交代的四点

1. **装**：`install.sh` 是 bash，Windows 上要用 WSL 或 Git Bash 跑；也可以在 PowerShell 里手动把 10 个 `amz-*` 目录拷进 agent 的技能目录。
2. **调**：CLI 调用改用 `scripts\cli_call.ps1`（功能与 bash 版一致）；**不要让 agent 去执行 `cli_call.sh`**，Windows 上没有 bash。
3. **Python**：文档里的 `python3` 要换成 `py`（或 `python`）；需要 Python 3.8+。
4. **编码**：Windows 控制台默认 GBK，脚本会输出中文和 `✅⚠️`，先 `chcp 65001` 或设 `PYTHONIOENCODING=utf-8`，否则可能抛 `UnicodeEncodeError`；PowerShell 被执行策略拦住时用 `-ExecutionPolicy Bypass`。

> 除 `cli_call.sh` / `gen-image.sh` / `install.sh` 三个 bash 脚本外，其余（`channel_check.py` / `doctor.py` / `amzdata.py` / `trend.py` / `data_check.py` / `cli_call.ps1`）都是跨平台的。
> `gen-image.sh` 本身不生图，只是转交给你自己的生图通道；没配置时会退化为「只输出提示词方案」，不影响其余环节。


