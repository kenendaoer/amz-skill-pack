#!/usr/bin/env python3
"""把 _shared/ 的内容同步进每个技能，使每个技能都是自包含的。

  _shared/*.py, *.sh  →  <skill>/scripts/     （可执行脚本，SKILL.md 里用 scripts/xxx 调用）
  _shared/*.md        →  <skill>/shared/      （文档，SKILL.md 里用 shared/xxx 引用）

幂等：重复运行结果一致。技能自有的脚本（如 profit_calculator.py）不会被覆盖。
"""

import shutil
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
SHARED = ROOT / "_shared"


def main():
    skills = sorted(p for p in ROOT.glob("amz-*") if p.is_dir())
    scripts = [p for p in SHARED.iterdir() if p.suffix in {".py", ".sh", ".ps1", ".env"}]
    docs = [p for p in SHARED.iterdir() if p.suffix == ".md"]

    for skill in skills:
        (skill / "scripts").mkdir(exist_ok=True)
        (skill / "shared").mkdir(exist_ok=True)
        for f in scripts:
            dst = skill / "scripts" / f.name
            shutil.copy2(f, dst)
            dst.chmod(0o755)
        for f in docs:
            shutil.copy2(f, skill / "shared" / f.name)
        # 全链路地图也放进 shared/，让每个技能自包含
        mapfile = ROOT / "amz-workflow-map.md"
        if mapfile.exists():
            shutil.copy2(mapfile, skill / "shared" / mapfile.name)
        print(f"同步 {skill.name}: scripts {len(scripts)} 个 / shared {len(docs) + 1} 个")

    # 根目录也放一份，方便直接阅读
    for f in scripts:
        pass
    print(f"\n共处理 {len(skills)} 个技能")


if __name__ == "__main__":
    main()
