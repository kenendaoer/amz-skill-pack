#!/usr/bin/env python3
"""检查 shell 脚本里「变量紧挨中文字符」的写法。

bash 会把 $VAR 紧跟的多字节字符当成变量名的一部分，导致
`$ENDPOINT（...` 这种写法报 unbound variable。中文技能包里极易踩到。

正确写法：${VAR}中文
"""

import re
import sys
from pathlib import Path

ROOT = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 \
    else Path(__file__).resolve().parent.parent

# $VAR / $1 后面直接跟非 ASCII 字符
PATTERN = re.compile(r"\$(\{?[A-Za-z_][A-Za-z0-9_]*\}?|[0-9])"
                     r"(?=[^\x00-\x7F])")


def main():
    problems = []
    for path in sorted(ROOT.rglob("*.sh")):
        for lineno, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1):
            if line.lstrip().startswith("#"):
                continue
            for m in PATTERN.finditer(line):
                var = m.group(1)
                if var.startswith("{"):
                    continue          # 已经是 ${VAR}，安全
                problems.append((path.relative_to(ROOT), lineno, m.group(0), line.strip()[:70]))

    if not problems:
        print("✅ 未发现「$VAR 紧挨中文」的写法")
        return 0

    print(f"⚠️  发现 {len(problems)} 处可能有问题的写法：\n")
    for rel, lineno, frag, line in problems:
        print(f"{rel}:{lineno}  {frag}...  →  {line}")
    print("\n改成 ${VAR}中文 即可。")
    return 1


if __name__ == "__main__":
    sys.exit(main())
